'use client';

import { useState, useCallback, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useIsMobile } from '@/hooks/use-mobile';
import { useStore } from '@/lib/store';
import { cn } from '@/lib/utils';

// PC Components
import { VideoCard } from '@/components/pc/VideoCard';
import { WatchPage } from '@/components/pc/WatchPage';
import { ChannelPage } from '@/components/pc/ChannelPage';
import { Header } from '@/components/layout/Header';
import { Sidebar } from '@/components/layout/Sidebar';

// Mobile Components
import { TikTokFeed } from '@/components/mobile/TikTokFeed';
import { TikTokPlayer } from '@/components/mobile/TikTokPlayer';

// Existing Components
import { AnimeCard } from '@/components/video/AnimeCard';
import { AnimeSection, AnimeGridSection } from '@/components/video/AnimeSection';

import {
  Search,
  Play,
  Star,
  ArrowLeft,
  Loader2,
  Tv,
  Film,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  Clock,
  Heart,
  History,
  Bookmark,
  Flame,
  Sparkles,
  X,
  Grid,
  Filter,
} from 'lucide-react';

// Types
interface SearchResult {
  slug: string;
  title: string;
  poster: string;
  year: string;
  type: string;
  score?: number;
}

interface Episode {
  id: string;
  number: number;
  title?: string;
}

interface AnimeInfo {
  id: string;
  title: string;
  synopsis: string;
  poster: string;
  banner?: string;
  slug: string;
  score: number;
  votes: number;
  episodes: Episode[];
  genres: string[];
  status: string;
  type: string;
  year: string;
}

interface Server {
  server: string;
  url: string;
}

interface EpisodeData {
  servers: {
    SUB: Server[];
    DUB: Server[];
  };
  episode: {
    number: number;
    title?: string;
  };
}

type ViewState = 'home' | 'search' | 'results' | 'channel' | 'player';

// Sample trending animes with episode data for YouTube-style grid
const TRENDING_ANIMES: SearchResult[] = [
  { slug: 'jujutsu-kaisen', title: 'Jujutsu Kaisen', poster: 'https://cdn.myanimelist.net/images/anime/1792/138022.jpg', year: '2023', type: 'TV', score: 8.7 },
  { slug: 'demon-slayer', title: 'Demon Slayer', poster: 'https://cdn.myanimelist.net/images/anime/1286/99889.jpg', year: '2023', type: 'TV', score: 8.5 },
  { slug: 'one-piece', title: 'One Piece', poster: 'https://cdn.myanimelist.net/images/anime/1244/138851.jpg', year: '2024', type: 'TV', score: 8.7 },
  { slug: 'attack-on-titan', title: 'Attack on Titan', poster: 'https://cdn.myanimelist.net/images/anime/1279/99217.jpg', year: '2023', type: 'TV', score: 9.0 },
  { slug: 'my-hero-academia', title: 'My Hero Academia', poster: 'https://cdn.myanimelist.net/images/anime/1565/111305.jpg', year: '2023', type: 'TV', score: 8.0 },
  { slug: 'chainsaw-man', title: 'Chainsaw Man', poster: 'https://cdn.myanimelist.net/images/anime/1806/126216.jpg', year: '2022', type: 'TV', score: 8.5 },
  { slug: 'spy-x-family', title: 'Spy x Family', poster: 'https://cdn.myanimelist.net/images/anime/1441/122795.jpg', year: '2023', type: 'TV', score: 8.6 },
  { slug: 'blue-lock', title: 'Blue Lock', poster: 'https://cdn.myanimelist.net/images/anime/1258/126929.jpg', year: '2023', type: 'TV', score: 8.4 },
  { slug: 'naruto-shippuden', title: 'Naruto Shippuden', poster: 'https://cdn.myanimelist.net/images/anime/1565/111305.jpg', year: '2017', type: 'TV', score: 8.3 },
  { slug: 'death-note', title: 'Death Note', poster: 'https://cdn.myanimelist.net/images/anime/9/9453.jpg', year: '2007', type: 'TV', score: 8.6 },
  { slug: 'fullmetal-alchemist', title: 'Fullmetal Alchemist', poster: 'https://cdn.myanimelist.net/images/anime/1208/94745.jpg', year: '2009', type: 'TV', score: 9.1 },
  { slug: 'tokyo-ghoul', title: 'Tokyo Ghoul', poster: 'https://cdn.myanimelist.net/images/anime/5/64449.jpg', year: '2014', type: 'TV', score: 7.8 },
];

// Generate mock video items for YouTube-style home
const generateMockVideos = (animes: SearchResult[]) => {
  return animes.flatMap(anime => {
    const episodeCount = Math.floor(Math.random() * 12) + 1;
    return Array.from({ length: Math.min(episodeCount, 3) }, (_, i) => ({
      animeSlug: anime.slug,
      animeTitle: anime.title,
      animePoster: anime.poster,
      episodeNumber: Math.floor(Math.random() * 24) + 1,
      episodeTitle: `${anime.title} - Episodio ${Math.floor(Math.random() * 24) + 1}`,
      views: `${Math.floor(Math.random() * 900 + 100)}K`,
      uploadedAt: `hace ${Math.floor(Math.random() * 30 + 1)} días`,
    }));
  }).sort(() => Math.random() - 0.5);
};

export default function AnimeStreamingPage() {
  const isMobile = useIsMobile();

  // Data state
  const [viewState, setViewState] = useState<ViewState>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [selectedAnime, setSelectedAnime] = useState<AnimeInfo | null>(null);
  const [selectedEpisode, setSelectedEpisode] = useState<Episode | null>(null);
  const [episodeData, setEpisodeData] = useState<EpisodeData | null>(null);
  const [selectedServer, setSelectedServer] = useState<Server | null>(null);
  const [audioType, setAudioType] = useState<'SUB' | 'DUB'>('SUB');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // UI state
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [currentFeedIndex, setCurrentFeedIndex] = useState(0);
  const [activeMobileTab, setActiveMobileTab] = useState('home');
  const [activeCategory, setActiveCategory] = useState('all');

  // Store
  const { 
    favorites, 
    watchHistory, 
    addToHistory,
    preferredAudio,
    searchHistory,
    addSearchTerm
  } = useStore();

  // Mock videos for home page
  const homeVideos = useMemo(() => generateMockVideos(TRENDING_ANIMES), []);

  // Categories
  const categories = [
    { id: 'all', label: 'Todos', icon: '🎬' },
    { id: 'tv', label: 'Series', icon: '📺' },
    { id: 'movie', label: 'Películas', icon: '🎥' },
    { id: 'action', label: 'Acción', icon: '⚔️' },
    { id: 'romance', label: 'Romance', icon: '💕' },
    { id: 'comedy', label: 'Comedia', icon: '😂' },
  ];

  // Filter by category
  const filteredResults = useMemo(() => {
    if (activeCategory === 'all') return searchResults;
    return searchResults.filter(a => a.type?.toLowerCase().includes(activeCategory));
  }, [searchResults, activeCategory]);

  // Continue watching from history
  const continueWatching = useMemo(() => {
    return watchHistory.slice(0, 6).map(h => ({
      slug: h.animeSlug,
      title: h.animeTitle,
      poster: h.animePoster,
      episodeNumber: h.episodeNumber,
      episodeTitle: h.episodeTitle
    }));
  }, [watchHistory]);

  // Search anime
  const handleSearch = useCallback(async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError(null);

    try {
      addSearchTerm(searchQuery);
      const response = await fetch(`/api/anime/search?q=${encodeURIComponent(searchQuery)}`);
      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setSearchResults(data.results || []);
      setViewState('results');
      setCurrentFeedIndex(0);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al buscar anime');
    } finally {
      setLoading(false);
    }
  }, [searchQuery, addSearchTerm]);

  // Get anime info (Channel)
  const handleSelectAnime = useCallback(async (result: SearchResult) => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/anime/info?slug=${encodeURIComponent(result.slug)}`);
      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setSelectedAnime(data);
      setViewState('channel');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al obtener información del anime');
    } finally {
      setLoading(false);
    }
  }, []);

  // Get episode servers (Player)
  const handleSelectEpisode = useCallback(async (episode: Episode) => {
    if (!selectedAnime) return;

    setLoading(true);
    setError(null);
    setSelectedEpisode(episode);
    setSelectedServer(null);
    setEpisodeData(null);

    try {
      const response = await fetch(
        `/api/anime/episode?slug=${encodeURIComponent(selectedAnime.slug)}&number=${episode.number}`
      );
      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      setEpisodeData(data);

      // Add to history
      addToHistory({
        animeSlug: selectedAnime.slug,
        animeTitle: selectedAnime.title,
        animePoster: selectedAnime.poster,
        episodeNumber: episode.number,
        episodeTitle: episode.title,
        timestamp: 0
      });

      // Auto-select server
      const subServers = data.servers?.SUB || [];
      const dubServers = data.servers?.DUB || [];

      if (preferredAudio === 'SUB' && subServers.length > 0) {
        setAudioType('SUB');
        setSelectedServer(subServers[0]);
      } else if (preferredAudio === 'DUB' && dubServers.length > 0) {
        setAudioType('DUB');
        setSelectedServer(dubServers[0]);
      } else if (subServers.length > 0) {
        setAudioType('SUB');
        setSelectedServer(subServers[0]);
      } else if (dubServers.length > 0) {
        setAudioType('DUB');
        setSelectedServer(dubServers[0]);
      }

      setViewState('player');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error al obtener episodio');
    } finally {
      setLoading(false);
    }
  }, [selectedAnime, preferredAudio, addToHistory]);

  // Handle audio type change
  const handleAudioTypeChange = useCallback((type: 'SUB' | 'DUB') => {
    setAudioType(type);
    if (episodeData) {
      const servers = episodeData.servers[type];
      if (servers && servers.length > 0) {
        setSelectedServer(servers[0]);
      } else {
        setSelectedServer(null);
      }
    }
  }, [episodeData]);

  // Navigate back
  const handleBack = useCallback(() => {
    if (viewState === 'player') {
      setViewState('channel');
      setSelectedServer(null);
      setEpisodeData(null);
    } else if (viewState === 'channel') {
      setViewState(searchResults.length > 0 ? 'results' : 'home');
      setSelectedAnime(null);
    } else if (viewState === 'results') {
      setViewState('home');
      setSearchResults([]);
    }
  }, [viewState, searchResults.length]);

  // Go to home
  const goToHome = useCallback(() => {
    setViewState('home');
    setSearchQuery('');
    setSearchResults([]);
    setSelectedAnime(null);
    setSelectedEpisode(null);
    setEpisodeData(null);
    setSelectedServer(null);
    setError(null);
    setActiveMobileTab('home');
  }, []);

  // Quick search from history
  const handleQuickSearch = useCallback((term: string) => {
    setSearchQuery(term);
    handleSearch();
  }, [handleSearch]);

  // Handle server change
  const handleServerChange = useCallback((server: Server) => {
    setSelectedServer(server);
  }, []);

  // Handle episode change
  const handleEpisodeChange = useCallback((episode: Episode) => {
    handleSelectEpisode(episode);
  }, [handleSelectEpisode]);

  // Related videos for watch page
  const relatedVideos = useMemo(() => {
    if (!selectedAnime) return [];
    return homeVideos.filter(v => v.animeSlug !== selectedAnime.slug).slice(0, 10);
  }, [selectedAnime, homeVideos]);

  // Mobile feed videos
  const feedVideos = useMemo(() => {
    return searchResults.map(anime => ({
      animeSlug: anime.slug,
      animeTitle: anime.title,
      animePoster: anime.poster,
      episodeNumber: 1,
    }));
  }, [searchResults]);

  // Loading screen
  if (loading && !selectedAnime && searchResults.length === 0 && viewState === 'home') {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-gray-950 via-gray-900 to-purple-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 flex items-center justify-center mx-auto mb-6 animate-pulse shadow-2xl">
            <Film className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-xl font-bold mb-2">
            <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent">
              Anime
            </span>
            <span className="text-white">Stream</span>
          </h2>
          <p className="text-gray-400">Cargando...</p>
        </div>
      </div>
    );
  }

  // ============ MOBILE VIEW (TikTok Style) ============
  if (isMobile) {
    return (
      <div className="fixed inset-0 bg-black">
        {/* Mobile Header */}
        <header className="fixed top-0 left-0 right-0 z-50">
          <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-b from-black/80 to-transparent">
            {viewState !== 'home' && (
              <button
                onClick={handleBack}
                className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 backdrop-blur-md"
              >
                <ArrowLeft className="w-5 h-5 text-white" />
              </button>
            )}
            
            {viewState === 'home' && (
              <button
                onClick={() => setActiveMobileTab('search')}
                className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 backdrop-blur-md"
              >
                <Search className="w-5 h-5 text-white" />
              </button>
            )}

            <button onClick={goToHome} className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 flex items-center justify-center">
                <Film className="w-4 h-4 text-white" />
              </div>
              <span className="font-bold text-white text-lg">
                Anime<span className="text-pink-400">Stream</span>
              </span>
            </button>

            <button
              onClick={() => setActiveMobileTab('profile')}
              className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 backdrop-blur-md"
            >
              <Tv className="w-5 h-5 text-white" />
            </button>
          </div>

          {/* Search Bar */}
          {activeMobileTab === 'search' && viewState === 'home' && (
            <div className="px-4 pb-4 bg-black/80 backdrop-blur-md">
              <form onSubmit={handleSearch}>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-white/50" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Buscar anime..."
                    className="w-full bg-white/10 text-white placeholder-white/50 rounded-xl px-10 py-3 text-sm border border-white/10 focus:border-pink-500 focus:outline-none"
                    autoFocus
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery('')}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                    >
                      <X className="w-5 h-5 text-white/50" />
                    </button>
                  )}
                </div>
              </form>
              
              {/* Search History */}
              {searchHistory.length > 0 && !searchQuery && (
                <div className="mt-4">
                  <p className="text-xs text-gray-400 mb-2">Búsquedas recientes</p>
                  <div className="flex flex-wrap gap-2">
                    {searchHistory.slice(0, 5).map((term) => (
                      <button
                        key={term}
                        onClick={() => handleQuickSearch(term)}
                        className="bg-white/10 text-white text-sm px-3 py-1.5 rounded-full"
                      >
                        {term}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </header>

        {/* HOME TAB */}
        {activeMobileTab === 'home' && viewState === 'home' && (
          <div className="fixed inset-0 pt-16 pb-20 overflow-y-auto">
            <div className="p-4">
              {/* Continue Watching */}
              {watchHistory.length > 0 && (
                <div className="mb-8">
                  <div className="flex items-center gap-2 mb-4">
                    <Clock className="w-5 h-5 text-purple-400" />
                    <h2 className="text-lg font-bold text-white">Continuar viendo</h2>
                  </div>
                  <div className="flex gap-3 overflow-x-auto scrollbar-hide">
                    {continueWatching.map((item) => (
                      <div
                        key={`${item.slug}-${item.episodeNumber}`}
                        onClick={() => handleSelectAnime({
                          slug: item.slug,
                          title: item.title,
                          poster: item.poster
                        })}
                        className="flex-shrink-0 w-40"
                      >
                        <div className="relative aspect-video rounded-lg overflow-hidden mb-2">
                          <img
                            src={item.poster}
                            alt={item.title}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                            <Play className="w-8 h-8 text-white" />
                          </div>
                          <div className="absolute bottom-1 right-1 bg-purple-500 text-white text-xs px-1.5 py-0.5 rounded">
                            EP {item.episodeNumber}
                          </div>
                        </div>
                        <p className="text-white text-sm font-medium line-clamp-1">{item.title}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Favorites */}
              {favorites.length > 0 && (
                <div className="mb-8">
                  <div className="flex items-center gap-2 mb-4">
                    <Heart className="w-5 h-5 text-pink-400" />
                    <h2 className="text-lg font-bold text-white">Mis favoritos</h2>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {favorites.slice(0, 6).map((anime) => (
                      <AnimeCard
                        key={anime.slug}
                        anime={anime}
                        onClick={() => handleSelectAnime(anime)}
                        variant="grid"
                        showActions={false}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Trending */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-4">
                  <Flame className="w-5 h-5 text-orange-400" />
                  <h2 className="text-lg font-bold text-white">Tendencias</h2>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  {TRENDING_ANIMES.map((anime) => (
                    <AnimeCard
                      key={anime.slug}
                      anime={anime}
                      onClick={() => handleSelectAnime(anime)}
                      variant="grid"
                    />
                  ))}
                </div>
              </div>

              {/* Empty state */}
              {favorites.length === 0 && watchHistory.length === 0 && (
                <div className="text-center py-12">
                  <div className="w-20 h-20 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-4">
                    <Sparkles className="w-10 h-10 text-purple-400" />
                  </div>
                  <h3 className="text-white font-semibold mb-2">¡Bienvenido!</h3>
                  <p className="text-gray-400 text-sm mb-6">Busca tu anime favorito para empezar</p>
                  <button
                    onClick={() => setActiveMobileTab('search')}
                    className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-6 py-3 rounded-xl font-medium"
                  >
                    Buscar anime
                  </button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SEARCH RESULTS - TikTok Feed */}
        {viewState === 'results' && searchResults.length > 0 && (
          <TikTokFeed
            videos={feedVideos}
            currentVideoIndex={currentFeedIndex}
            onVideoChange={setCurrentFeedIndex}
            onSelectAnime={(video) => handleSelectAnime({
              slug: video.animeSlug,
              title: video.animeTitle,
              poster: video.animePoster
            })}
          />
        )}

        {/* ANIME DETAIL (Channel) */}
        {viewState === 'channel' && selectedAnime && (
          <div className="fixed inset-0 bg-black pt-16 pb-20 overflow-y-auto">
            <div className="p-4">
              {/* Poster & Info */}
              <div className="flex gap-4 mb-6">
                <img
                  src={selectedAnime.poster}
                  alt={selectedAnime.title}
                  className="w-32 rounded-lg shadow-lg"
                />
                <div className="flex-1">
                  <h1 className="text-lg font-bold text-white mb-2">{selectedAnime.title}</h1>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {selectedAnime.score > 0 && (
                      <Badge className="bg-yellow-500/20 text-yellow-400">
                        <Star className="w-3 h-3 mr-1 fill-yellow-400" />
                        {selectedAnime.score.toFixed(1)}
                      </Badge>
                    )}
                    <Badge className="bg-purple-500/20">{selectedAnime.type}</Badge>
                    {selectedAnime.year && (
                      <Badge className="bg-white/10">{selectedAnime.year}</Badge>
                    )}
                  </div>
                  {selectedAnime.genres && selectedAnime.genres.length > 0 && (
                    <div className="flex flex-wrap gap-1">
                      {selectedAnime.genres.slice(0, 4).map((genre) => (
                        <span key={genre} className="text-xs text-gray-400">{genre}</span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Synopsis */}
              {selectedAnime.synopsis && (
                <p className="text-gray-300 text-sm mb-6 line-clamp-4">{selectedAnime.synopsis}</p>
              )}

              {/* Episodes Grid */}
              <h2 className="text-white font-bold mb-4">
                Episodios ({selectedAnime.episodes.length})
              </h2>
              <div className="grid grid-cols-4 gap-2">
                {selectedAnime.episodes.map((ep) => (
                  <button
                    key={ep.id}
                    onClick={() => handleSelectEpisode(ep)}
                    disabled={loading}
                    className="aspect-square bg-gradient-to-br from-purple-900/50 to-gray-900 rounded-lg border border-white/10 flex flex-col items-center justify-center text-white font-bold hover:border-purple-500 transition-all active:scale-95"
                  >
                    <span className="text-lg">{ep.number}</span>
                    <Play className="w-4 h-4 opacity-60 mt-1" />
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* PLAYER - TikTok Style */}
        {viewState === 'player' && selectedAnime && selectedEpisode && (
          <TikTokPlayer
            anime={selectedAnime}
            episode={selectedEpisode}
            episodeData={episodeData}
            selectedServer={selectedServer}
            audioType={audioType}
            loading={loading}
            onServerChange={handleServerChange}
            onAudioTypeChange={handleAudioTypeChange}
            onEpisodeChange={handleEpisodeChange}
            onBack={handleBack}
          />
        )}

        {/* FAVORITES TAB */}
        {activeMobileTab === 'favorites' && viewState === 'home' && (
          <div className="fixed inset-0 pt-16 pb-20 overflow-y-auto">
            <div className="p-4">
              <h2 className="text-xl font-bold text-white mb-4">Mis Favoritos</h2>
              {favorites.length > 0 ? (
                <div className="grid grid-cols-3 gap-3">
                  {favorites.map((anime) => (
                    <AnimeCard
                      key={anime.slug}
                      anime={anime}
                      onClick={() => handleSelectAnime(anime)}
                      variant="grid"
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Heart className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Aún no tienes favoritos</p>
                  <p className="text-gray-500 text-sm">Toca el corazón en cualquier anime para guardarlo</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* HISTORY TAB */}
        {activeMobileTab === 'history' && viewState === 'home' && (
          <div className="fixed inset-0 pt-16 pb-20 overflow-y-auto">
            <div className="p-4">
              <h2 className="text-xl font-bold text-white mb-4">Historial</h2>
              {watchHistory.length > 0 ? (
                <div className="space-y-3">
                  {watchHistory.map((item) => (
                    <div
                      key={`${item.animeSlug}-${item.episodeNumber}-${item.watchedAt}`}
                      onClick={() => handleSelectAnime({
                        slug: item.animeSlug,
                        title: item.animeTitle,
                        poster: item.animePoster
                      })}
                      className="flex gap-3 p-2 rounded-lg bg-white/5 hover:bg-white/10 cursor-pointer"
                    >
                      <img
                        src={item.animePoster}
                        alt={item.animeTitle}
                        className="w-20 h-12 object-cover rounded"
                      />
                      <div>
                        <p className="text-white text-sm font-medium">{item.animeTitle}</p>
                        <p className="text-gray-400 text-xs">Episodio {item.episodeNumber}</p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <History className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Historial vacío</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Empty Search Results */}
        {viewState === 'results' && searchResults.length === 0 && !loading && (
          <div className="fixed inset-0 flex items-center justify-center text-white text-center p-8 pt-24">
            <div>
              <span className="text-5xl mb-4 block">🔍</span>
              <h2 className="text-xl font-bold mb-2">Sin resultados</h2>
              <p className="text-gray-400">Intenta con otra búsqueda</p>
            </div>
          </div>
        )}

        {/* Bottom Navigation */}
        <nav className="fixed bottom-0 left-0 right-0 z-50">
          <div className="bg-black/90 backdrop-blur-xl border-t border-white/10">
            <div className="flex items-center justify-around py-2 pb-6">
              {[
                { id: 'home', icon: Tv, label: 'Inicio' },
                { id: 'search', icon: Search, label: 'Buscar' },
                { id: 'favorites', icon: Heart, label: 'Favoritos' },
                { id: 'history', icon: History, label: 'Historial' },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveMobileTab(item.id);
                    if (item.id === 'home') goToHome();
                  }}
                  className={cn(
                    "flex flex-col items-center gap-0.5 px-4 py-1 transition-all",
                    activeMobileTab === item.id ? "text-white" : "text-white/50"
                  )}
                >
                  <item.icon className={cn(
                    "w-6 h-6",
                    activeMobileTab === item.id && "fill-white"
                  )} />
                  <span className="text-[10px] font-medium">{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        </nav>
      </div>
    );
  }

  // ============ DESKTOP VIEW (YouTube Style) ============
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-purple-950 text-white">
      {/* Header */}
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onSearch={handleSearch}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        isSidebarOpen={isSidebarOpen}
        onHome={goToHome}
      />

      {/* Sidebar */}
      <Sidebar
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
        onHome={goToHome}
        favorites={favorites}
        onQuickSearch={handleQuickSearch}
        searchHistory={searchHistory}
      />

      {/* Main Content */}
      <main
        className={cn(
          "pt-14 min-h-screen transition-all duration-300",
          isSidebarOpen ? "ml-64" : "ml-0"
        )}
      >
        {/* Error Message */}
        {error && (
          <div className="px-4 py-4">
            <div className="rounded-lg border border-red-500/50 bg-red-500/10 p-4 text-red-400">
              {error}
            </div>
          </div>
        )}

        {/* HOME VIEW - YouTube Style Grid */}
        {viewState === 'home' && (
          <div>
            {/* Category Chips */}
            <div className="sticky top-14 z-30 bg-gray-950/95 backdrop-blur-xl border-b border-white/10">
              <div className="flex items-center gap-2 px-6 py-3 overflow-x-auto scrollbar-hide">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id)}
                    className={cn(
                      "flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all",
                      activeCategory === category.id
                        ? "bg-white text-black"
                        : "bg-white/10 hover:bg-white/20 text-white"
                    )}
                  >
                    <span>{category.icon}</span>
                    <span>{category.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="p-6">
              {/* Continue Watching Section */}
              {watchHistory.length > 0 && (
                <div className="mb-8">
                  <div className="flex items-center gap-2 mb-4">
                    <Clock className="w-5 h-5 text-purple-400" />
                    <h2 className="text-xl font-bold text-white">Continuar viendo</h2>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {watchHistory.slice(0, 4).map((item) => (
                      <VideoCard
                        key={`${item.animeSlug}-${item.episodeNumber}`}
                        video={{
                          animeSlug: item.animeSlug,
                          animeTitle: item.animeTitle,
                          animePoster: item.animePoster,
                          episodeNumber: item.episodeNumber,
                          episodeTitle: item.episodeTitle,
                        }}
                        onClick={() => handleSelectAnime({
                          slug: item.animeSlug,
                          title: item.animeTitle,
                          poster: item.animePoster
                        })}
                      />
                    ))}
                  </div>
                </div>
              )}

              {/* Recommended Videos - YouTube Style */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-4">
                  <Flame className="w-5 h-5 text-orange-400" />
                  <h2 className="text-xl font-bold text-white">Recomendados</h2>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                  {homeVideos.slice(0, 12).map((video, index) => (
                    <VideoCard
                      key={`${video.animeSlug}-${video.episodeNumber}-${index}`}
                      video={video}
                      onClick={() => handleSelectAnime({
                        slug: video.animeSlug,
                        title: video.animeTitle,
                        poster: video.animePoster
                      })}
                    />
                  ))}
                </div>
              </div>

              {/* Trending Animes as Channels */}
              <div className="mb-8">
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="w-5 h-5 text-pink-400" />
                  <h2 className="text-xl font-bold text-white">Canales populares</h2>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {TRENDING_ANIMES.map((anime) => (
                    <button
                      key={anime.slug}
                      onClick={() => handleSelectAnime(anime)}
                      className="group text-center"
                    >
                      <div className="relative mx-auto w-24 h-24 mb-3">
                        <img
                          src={anime.poster}
                          alt={anime.title}
                          className="w-full h-full rounded-full object-cover border-2 border-transparent group-hover:border-purple-500 transition-all"
                        />
                      </div>
                      <h3 className="text-white text-sm font-medium line-clamp-1 group-hover:text-purple-400">
                        {anime.title}
                      </h3>
                      <p className="text-gray-500 text-xs">{anime.score?.toFixed(1)} ★</p>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* SEARCH RESULTS VIEW */}
        {viewState === 'results' && (
          <div>
            {/* Category Chips */}
            <div className="sticky top-14 z-30 bg-gray-950/95 backdrop-blur-xl border-b border-white/10">
              <div className="flex items-center gap-2 px-6 py-3 overflow-x-auto scrollbar-hide">
                {categories.map((category) => (
                  <button
                    key={category.id}
                    onClick={() => setActiveCategory(category.id)}
                    className={cn(
                      "flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all",
                      activeCategory === category.id
                        ? "bg-white text-black"
                        : "bg-white/10 hover:bg-white/20 text-white"
                    )}
                  >
                    <span>{category.icon}</span>
                    <span>{category.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="p-6">
              <div className="mb-6">
                <h2 className="text-xl font-bold">Resultados para "{searchQuery}"</h2>
                <p className="text-gray-400 text-sm">{filteredResults.length} encontrados</p>
              </div>

              <AnimeGridSection
                animes={filteredResults}
                onSelectAnime={handleSelectAnime}
                columns={6}
              />
            </div>
          </div>
        )}

        {/* CHANNEL VIEW (Anime Detail) */}
        {viewState === 'channel' && selectedAnime && (
          <ChannelPage
            anime={selectedAnime}
            loading={loading}
            onPlayEpisode={handleSelectEpisode}
            onBack={handleBack}
          />
        )}

        {/* PLAYER VIEW - YouTube Watch Page */}
        {viewState === 'player' && selectedAnime && selectedEpisode && (
          <WatchPage
            anime={selectedAnime}
            episode={selectedEpisode}
            episodeData={episodeData}
            selectedServer={selectedServer}
            audioType={audioType}
            loading={loading}
            onServerChange={handleServerChange}
            onAudioTypeChange={handleAudioTypeChange}
            onEpisodeChange={handleEpisodeChange}
            relatedVideos={relatedVideos}
            onRelatedClick={(video) => handleSelectAnime({
              slug: video.animeSlug,
              title: video.animeTitle,
              poster: video.animePoster
            })}
          />
        )}
      </main>
    </div>
  );
}
