import { NextRequest, NextResponse } from 'next/server';

interface Server {
  server: string;
  url: string;
}

interface EpisodeData {
  servers: {
    SUB: Server[];
    DUB: Server[];
  };
  episode: {
    number: number;
    title?: string;
  };
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const slug = searchParams.get('slug');
  const number = searchParams.get('number');

  if (!slug || !number) {
    return NextResponse.json({ error: 'Slug and number parameters are required' }, { status: 400 });
  }

  try {
    const response = await fetch(`https://animeav1.com/media/${slug}/${number}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3',
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const html = await response.text();

    const episodeData: EpisodeData = {
      servers: {
        SUB: [],
        DUB: [],
      },
      episode: {
        number: parseInt(number),
      },
    };

    // Extract only the embeds section (not downloads)
    const embedsSectionMatch = html.match(/embeds:\{([\s\S]*?)\},downloads:/);
    if (!embedsSectionMatch) {
      // Fallback: try without downloads section
      const altMatch = html.match(/embeds:\{([\s\S]*?)\}\}/);
      if (!altMatch) {
        return NextResponse.json(episodeData);
      }
    }
    
    const embedsSection = embedsSectionMatch ? embedsSectionMatch[1] : '';
    
    // Extract all server objects
    const serverRegex = /\{server:"([^"]+)",url:"([^"]+)"\}/g;
    
    // Find SUB servers within embeds section only
    const subMatch = embedsSection.match(/SUB:\[([\s\S]*?)\]/);
    if (subMatch) {
      const subStr = subMatch[1];
      let serverMatch;
      serverRegex.lastIndex = 0;
      while ((serverMatch = serverRegex.exec(subStr)) !== null) {
        episodeData.servers.SUB.push({
          server: serverMatch[1],
          url: serverMatch[2],
        });
      }
    }

    // Find DUB servers within embeds section only
    const dubMatch = embedsSection.match(/DUB:\[([\s\S]*?)\]/);
    if (dubMatch) {
      const dubStr = dubMatch[1];
      let serverMatch;
      serverRegex.lastIndex = 0;
      while ((serverMatch = serverRegex.exec(dubStr)) !== null) {
        episodeData.servers.DUB.push({
          server: serverMatch[1],
          url: serverMatch[2],
        });
      }
    }

    // Alternative: Extract iframe URL directly from HTML if embeds not found
    if (episodeData.servers.SUB.length === 0 && episodeData.servers.DUB.length === 0) {
      const iframeMatch = html.match(/<iframe[^>]*src="([^"]+)"[^>]*title="Episodio/);
      if (iframeMatch) {
        episodeData.servers.SUB.push({
          server: 'HLS',
          url: iframeMatch[1],
        });
      }
    }

    return NextResponse.json(episodeData);
  } catch (error) {
    console.error('Episode fetch error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch episode data', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
