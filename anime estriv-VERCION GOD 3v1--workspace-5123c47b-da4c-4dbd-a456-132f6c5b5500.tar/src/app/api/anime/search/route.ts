import { NextRequest, NextResponse } from 'next/server';

interface SearchResult {
  slug: string;
  title: string;
  poster: string;
  year: string;
  type: string;
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const query = searchParams.get('q');

  if (!query) {
    return NextResponse.json({ error: 'Query parameter is required' }, { status: 400 });
  }

  try {
    const response = await fetch(`https://animeav1.com/catalogo?search=${encodeURIComponent(query)}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3',
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const html = await response.text();
    const results: SearchResult[] = [];

    // Parse the HTML to extract anime results
    // Looking for anime cards in the catalog
    const cardRegex = /<a[^>]*href="\/media\/([^"]+)"[^>]*class="[^"]*card[^"]*"[^>]*>([\s\S]*?)<\/a>/gi;
    let match;

    while ((match = cardRegex.exec(html)) !== null) {
      const slug = match[1].replace(/\/$/, '');
      const cardContent = match[2];

      // Extract title
      const titleMatch = cardContent.match(/<h3[^>]*>([^<]+)<\/h3>/i) || 
                         cardContent.match(/<p[^>]*class="[^"]*title[^"]*"[^>]*>([^<]+)<\/p>/i) ||
                         cardContent.match(/title="([^"]+)"/i);
      const title = titleMatch ? titleMatch[1].trim() : 'Unknown';

      // Extract poster/image
      const imgMatch = cardContent.match(/src="([^"]+)"/i) || 
                       cardContent.match(/data-src="([^"]+)"/i) ||
                       cardContent.match(/background-image:\s*url\(['"]?([^'")\s]+)['"]?\)/i);
      const poster = imgMatch ? imgMatch[1] : '';

      // Extract year
      const yearMatch = cardContent.match(/\b(19\d{2}|20\d{2})\b/);
      const year = yearMatch ? yearMatch[1] : '';

      // Extract type
      const typeMatch = cardContent.match(/(TV|Movie|OVA|ONA|Especial)/i);
      const type = typeMatch ? typeMatch[1] : 'TV';

      if (slug && !results.find(r => r.slug === slug)) {
        results.push({
          slug,
          title,
          poster: poster.startsWith('//') ? `https:${poster}` : poster,
          year,
          type,
        });
      }
    }

    // Alternative parsing if the above doesn't work
    if (results.length === 0) {
      // Try a more generic approach
      const animeRegex = /<article[^>]*>[\s\S]*?<a[^>]*href="\/media\/([^"]+)"[\s\S]*?<img[^>]*src="([^"]+)"[\s\S]*?(?:<h[^>]*>([^<]+)<\/h[^>]*>|title="([^"]+)")[\s\S]*?<\/article>/gi;
      
      while ((match = animeRegex.exec(html)) !== null) {
        const slug = match[1].replace(/\/$/, '');
        const poster = match[2];
        const title = (match[3] || match[4] || 'Unknown').trim();

        if (slug && !results.find(r => r.slug === slug)) {
          results.push({
            slug,
            title,
            poster: poster.startsWith('//') ? `https:${poster}` : poster,
            year: '',
            type: 'TV',
          });
        }
      }
    }

    // Another fallback - look for any media links
    if (results.length === 0) {
      const mediaRegex = /href="\/media\/([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi;
      
      while ((match = mediaRegex.exec(html)) !== null) {
        const slug = match[1].split('/')[0].replace(/\/$/, '');
        const content = match[2];
        
        // Skip pagination or other non-anime links
        if (slug.includes('?') || slug.length < 3) continue;

        const imgMatch = content.match(/src="([^"]+)"/i);
        const textMatch = content.match(/>([^<]+)</);
        
        if (slug && !results.find(r => r.slug === slug)) {
          results.push({
            slug,
            title: textMatch ? textMatch[1].trim() : slug.replace(/-/g, ' '),
            poster: imgMatch && imgMatch[1] ? (imgMatch[1].startsWith('//') ? `https:${imgMatch[1]}` : imgMatch[1]) : '',
            year: '',
            type: 'TV',
          });
        }
      }
    }

    return NextResponse.json({ results });
  } catch (error) {
    console.error('Search error:', error);
    return NextResponse.json(
      { error: 'Failed to search anime', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
