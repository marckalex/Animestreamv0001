import { NextRequest, NextResponse } from 'next/server';

interface Episode {
  id: string;
  number: number;
  title?: string;
}

interface AnimeInfo {
  id: string;
  title: string;
  synopsis: string;
  poster: string;
  banner?: string;
  slug: string;
  score: number;
  votes: number;
  episodes: Episode[];
  genres: string[];
  status: string;
  type: string;
  year: string;
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const slug = searchParams.get('slug');

  if (!slug) {
    return NextResponse.json({ error: 'Slug parameter is required' }, { status: 400 });
  }

  try {
    // Use URL without trailing slash to avoid 308 redirect
    const response = await fetch(`https://animeav1.com/media/${slug}`, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'es-ES,es;q=0.8,en-US;q=0.5,en;q=0.3',
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const html = await response.text();

    // Extract anime ID from CDN URLs (e.g., cdn.animeav1.com/covers/2067.jpg)
    const idMatch = html.match(/cdn\.animeav1\.com\/covers\/(\d+)\.jpg/);
    const animeId = idMatch ? idMatch[1] : '';

    // Extract title from h1
    const titleMatch = html.match(/<h1[^>]*class="[^"]*text-lead[^"]*"[^>]*>([^<]+)<\/h1>/);
    const title = titleMatch ? titleMatch[1].trim() : slug.replace(/-/g, ' ');

    // Extract synopsis from the entry div
    const synopsisMatch = html.match(/<div class="entry[^"]*"[^>]*>[\s\S]*?<p>([\s\S]*?)<\/p>/);
    const synopsis = synopsisMatch ? synopsisMatch[1].replace(/<[^>]*>/g, '').trim() : '';

    // Extract score
    const scoreMatch = html.match(/<div class="text-lead text-2xl font-bold">([\d.]+)<\/div>/);
    const score = scoreMatch ? parseFloat(scoreMatch[1]) : 0;

    // Extract votes
    const votesMatch = html.match(/<span class="font-bold">(\d+)<\/span>\s*Votos/);
    const votes = votesMatch ? parseInt(votesMatch[1].replace(/,/g, '')) : 0;

    // Extract genres
    const genres: string[] = [];
    const genreRegex = /href="\/catalogo\?genre=([^"]+)"[^>]*>([^<]+)<\/a>/g;
    let genreMatch;
    while ((genreMatch = genreRegex.exec(html)) !== null) {
      genres.push(genreMatch[2]);
    }

    // Extract type, year, status from the info line
    const infoMatch = html.match(/<div class="flex flex-wrap items-center gap-2 text-sm">([\s\S]*?)<\/div>/);
    let type = 'TV';
    let year = '';
    let status = 'Desconocido';
    
    if (infoMatch) {
      const infoContent = infoMatch[1];
      
      // Extract type (TV Anime, Movie, etc.)
      const typeMatch = infoContent.match(/<span>([^<]+)<\/span>/);
      if (typeMatch) {
        type = typeMatch[1].trim();
      }
      
      // Extract year (4 digit number)
      const yearMatch = infoContent.match(/\b(20\d{2})\b/);
      if (yearMatch) {
        year = yearMatch[1];
      }
      
      // Extract status (Finalizado, En emisión, etc.) - usually last item
      const statusMatch = infoContent.match(/<span>(Finalizado|En emisión|Próximamente)<\/span>/);
      if (statusMatch) {
        status = statusMatch[1];
      }
    }

    // Extract episodes from the script data (parse JavaScript object)
    const episodes: Episode[] = [];
    
    // Method 1: Try to find episodes in the SvelteKit data
    const episodesDataMatch = html.match(/episodes:\[([\s\S]*?)\],relations:/);
    if (episodesDataMatch) {
      const episodesStr = episodesDataMatch[1];
      // Parse episode objects like {id:30903,number:1}
      const epRegex = /\{id:(\d+),number:(\d+)\}/g;
      let epMatch;
      while ((epMatch = epRegex.exec(episodesStr)) !== null) {
        episodes.push({
          id: epMatch[1],
          number: parseInt(epMatch[2]),
        });
      }
    }

    // Method 2: Fallback - extract from episode links in HTML
    if (episodes.length === 0) {
      const epLinkRegex = /href="\/media\/[^"]+\/(\d+)"[^>]*>[\s\S]*?Episodio[\s\S]*?<span[^>]*>(\d+)<\/span>/g;
      let epLinkMatch;
      while ((epLinkMatch = epLinkRegex.exec(html)) !== null) {
        const epNum = parseInt(epLinkMatch[2]);
        if (!episodes.find(e => e.number === epNum)) {
          episodes.push({
            id: epLinkMatch[1],
            number: epNum,
          });
        }
      }
    }

    // Sort episodes by number
    episodes.sort((a, b) => a.number - b.number);

    const animeInfo: AnimeInfo = {
      id: animeId,
      title: title,
      synopsis: synopsis,
      poster: animeId ? `https://cdn.animeav1.com/covers/${animeId}.jpg` : '',
      banner: animeId ? `https://cdn.animeav1.com/backdrops/${animeId}.jpg` : '',
      slug: slug,
      score: score,
      votes: votes,
      episodes: episodes,
      genres: genres,
      status: status,
      type: type,
      year: year,
    };

    return NextResponse.json(animeInfo);
  } catch (error) {
    console.error('Info fetch error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch anime info', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    );
  }
}
