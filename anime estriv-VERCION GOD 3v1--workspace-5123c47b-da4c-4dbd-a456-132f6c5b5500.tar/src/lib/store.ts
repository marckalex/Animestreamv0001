import { create } from 'zustand'
import { persist } from 'zustand/middleware'

// Types
interface FavoriteAnime {
  slug: string
  title: string
  poster: string
  type?: string
  score?: number
  addedAt: number
}

interface WatchHistoryItem {
  animeSlug: string
  animeTitle: string
  animePoster: string
  episodeNumber: number
  episodeTitle?: string
  timestamp: number
  watchedAt: number
}

interface StoreState {
  // Favorites
  favorites: FavoriteAnime[]
  addFavorite: (anime: Omit<FavoriteAnime, 'addedAt'>) => void
  removeFavorite: (slug: string) => void
  isFavorite: (slug: string) => boolean

  // Watch History
  watchHistory: WatchHistoryItem[]
  addToHistory: (item: Omit<WatchHistoryItem, 'watchedAt'>) => void
  clearHistory: () => void
  getContinueWatching: () => WatchHistoryItem[]

  // Liked animes (for feed)
  likedAnimes: Set<string>
  toggleLike: (slug: string) => void
  isLiked: (slug: string) => boolean

  // Preferences
  preferredAudio: 'SUB' | 'DUB'
  setPreferredAudio: (audio: 'SUB' | 'DUB') => void
  
  // Theme
  isDarkMode: boolean
  toggleDarkMode: () => void
  
  // Search history
  searchHistory: string[]
  addSearchTerm: (term: string) => void
  clearSearchHistory: () => void
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      // Favorites
      favorites: [],
      addFavorite: (anime) => set((state) => ({
        favorites: [...state.favorites, { ...anime, addedAt: Date.now() }]
      })),
      removeFavorite: (slug) => set((state) => ({
        favorites: state.favorites.filter((f) => f.slug !== slug)
      })),
      isFavorite: (slug) => get().favorites.some((f) => f.slug === slug),

      // Watch History
      watchHistory: [],
      addToHistory: (item) => set((state) => {
        // Remove old entry for same episode
        const filtered = state.watchHistory.filter(
          (h) => !(h.animeSlug === item.animeSlug && h.episodeNumber === item.episodeNumber)
        )
        return {
          watchHistory: [{ ...item, watchedAt: Date.now() }, ...filtered].slice(0, 100)
        }
      }),
      clearHistory: () => set({ watchHistory: [] }),
      getContinueWatching: () => {
        const history = get().watchHistory
        // Get unique animes with their latest episode
        const seen = new Set<string>()
        return history.filter((item) => {
          if (seen.has(item.animeSlug)) return false
          seen.add(item.animeSlug)
          return true
        }).slice(0, 10)
      },

      // Liked
      likedAnimes: new Set(),
      toggleLike: (slug) => set((state) => {
        const newLiked = new Set(state.likedAnimes)
        if (newLiked.has(slug)) {
          newLiked.delete(slug)
        } else {
          newLiked.add(slug)
        }
        return { likedAnimes: newLiked }
      }),
      isLiked: (slug) => get().likedAnimes.has(slug),

      // Preferences
      preferredAudio: 'SUB',
      setPreferredAudio: (audio) => set({ preferredAudio: audio }),

      // Theme
      isDarkMode: true,
      toggleDarkMode: () => set((state) => ({ isDarkMode: !state.isDarkMode })),

      // Search History
      searchHistory: [],
      addSearchTerm: (term) => set((state) => {
        const filtered = state.searchHistory.filter((t) => t !== term)
        return { searchHistory: [term, ...filtered].slice(0, 10) }
      }),
      clearSearchHistory: () => set({ searchHistory: [] }),
    }),
    {
      name: 'animestream-storage',
      partialize: (state) => ({
        favorites: state.favorites,
        watchHistory: state.watchHistory,
        likedAnimes: Array.from(state.likedAnimes),
        preferredAudio: state.preferredAudio,
        isDarkMode: state.isDarkMode,
        searchHistory: state.searchHistory,
      }),
      onRehydrateStorage: () => (state) => {
        if (state) {
          // Convert array back to Set
          state.likedAnimes = new Set(state.likedAnimes as unknown as string[])
        }
      },
    }
  )
)
