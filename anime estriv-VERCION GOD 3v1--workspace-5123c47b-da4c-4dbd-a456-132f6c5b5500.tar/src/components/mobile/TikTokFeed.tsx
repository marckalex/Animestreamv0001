'use client';

import { useRef, useState, useCallback, useEffect, useMemo } from 'react';
import { cn } from '@/lib/utils';
import { useStore } from '@/lib/store';
import {
  Heart,
  MessageCircle,
  Share2,
  Bookmark,
  MoreHorizontal,
  Play,
  Pause,
  Volume2,
  VolumeX,
  Music,
  ChevronDown,
  Verified,
} from 'lucide-react';

interface VideoItem {
  animeSlug: string;
  animeTitle: string;
  animePoster: string;
  episodeNumber: number;
  episodeTitle?: string;
}

interface TikTokFeedProps {
  videos: VideoItem[];
  currentVideoIndex: number;
  onVideoChange: (index: number) => void;
  onSelectAnime: (video: VideoItem) => void;
}

export function TikTokFeed({ videos, currentVideoIndex, onVideoChange, onSelectAnime }: TikTokFeedProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const touchStartY = useRef(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const [swipeOffset, setSwipeOffset] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [showHeart, setShowHeart] = useState(false);
  const [lastTapTime, setLastTapTime] = useState(0);
  
  const { likedAnimes, toggleLike, isFavorite, addFavorite, removeFavorite } = useStore();
  const currentVideo = videos[currentVideoIndex];
  const isLiked = currentVideo ? likedAnimes.has(currentVideo.animeSlug) : false;
  const isFav = currentVideo ? isFavorite(currentVideo.animeSlug) : false;

  // Touch handlers
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    setIsSwiping(true);
    
    // Double tap detection
    const now = Date.now();
    if (now - lastTapTime < 300 && currentVideo) {
      // Double tap - like
      setShowHeart(true);
      if (!isLiked) {
        toggleLike(currentVideo.animeSlug);
      }
      setTimeout(() => setShowHeart(false), 800);
    }
    setLastTapTime(now);
  }, [lastTapTime, currentVideo, isLiked, toggleLike]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isSwiping || isTransitioning) return;
    const diff = touchStartY.current - e.touches[0].clientY;
    setSwipeOffset(Math.max(-200, Math.min(200, diff)));
  }, [isSwiping, isTransitioning]);

  const goToNext = useCallback(() => {
    if (currentVideoIndex < videos.length - 1 && !isTransitioning) {
      setIsTransitioning(true);
      onVideoChange(currentVideoIndex + 1);
      setTimeout(() => setIsTransitioning(false), 400);
    }
  }, [currentVideoIndex, videos.length, onVideoChange, isTransitioning]);

  const goToPrev = useCallback(() => {
    if (currentVideoIndex > 0 && !isTransitioning) {
      setIsTransitioning(true);
      onVideoChange(currentVideoIndex - 1);
      setTimeout(() => setIsTransitioning(false), 400);
    }
  }, [currentVideoIndex, onVideoChange, isTransitioning]);

  const handleTouchEnd = useCallback(() => {
    setIsSwiping(false);
    if (swipeOffset > 80) {
      goToNext();
    } else if (swipeOffset < -80) {
      goToPrev();
    }
    setSwipeOffset(0);
  }, [swipeOffset, goToNext, goToPrev]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp') goToPrev();
      else if (e.key === 'ArrowDown') goToNext();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [goToNext, goToPrev]);

  const handleLike = useCallback(() => {
    if (currentVideo) {
      toggleLike(currentVideo.animeSlug);
    }
  }, [currentVideo, toggleLike]);

  const handleFavorite = useCallback(() => {
    if (currentVideo) {
      if (isFav) {
        removeFavorite(currentVideo.animeSlug);
      } else {
        addFavorite({
          slug: currentVideo.animeSlug,
          title: currentVideo.animeTitle,
          poster: currentVideo.animePoster,
        });
      }
    }
  }, [currentVideo, isFav, addFavorite, removeFavorite]);

  if (!currentVideo) return null;

  // Mock like count
  const likeCount = Math.floor(Math.random() * 500 + 50);
  const commentCount = Math.floor(Math.random() * 200 + 20);
  const shareCount = Math.floor(Math.random() * 100 + 10);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 bg-black overflow-hidden touch-none"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Video Background (Anime Poster as placeholder) */}
      <div
        className={cn(
          "absolute inset-0 transition-all ease-out",
          isSwiping ? "duration-0" : "duration-400"
        )}
        style={{ transform: `translateY(${-swipeOffset * 0.3}px)` }}
      >
        <img
          src={currentVideo.animePoster}
          alt={currentVideo.animeTitle}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/60" />
        
        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center opacity-50">
            <Play className="w-10 h-10 text-white ml-1" />
          </div>
        </div>
      </div>

      {/* Double Tap Heart Animation */}
      {showHeart && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30">
          <Heart className="w-32 h-32 text-pink-500 fill-pink-500 animate-ping" />
        </div>
      )}

      {/* Right Side Actions */}
      <div className="absolute right-3 bottom-32 flex flex-col items-center gap-5 z-20">
        {/* Profile */}
        <div className="relative">
          <img
            src={currentVideo.animePoster}
            alt={currentVideo.animeTitle}
            className="w-12 h-12 rounded-full border-2 border-white object-cover"
          />
          <button className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-6 h-6 bg-pink-500 rounded-full flex items-center justify-center">
            <span className="text-white text-lg font-bold leading-none">+</span>
          </button>
        </div>

        {/* Like */}
        <button onClick={handleLike} className="flex flex-col items-center">
          <div className={cn(
            "w-12 h-12 flex items-center justify-center",
            isLiked && "animate-pulse"
          )}>
            <Heart className={cn(
              "w-8 h-8 transition-colors",
              isLiked ? "text-pink-500 fill-pink-500" : "text-white"
            )} />
          </div>
          <span className="text-white text-xs font-semibold">{likeCount}</span>
        </button>

        {/* Comment */}
        <button className="flex flex-col items-center">
          <div className="w-12 h-12 flex items-center justify-center">
            <MessageCircle className="w-8 h-8 text-white" />
          </div>
          <span className="text-white text-xs font-semibold">{commentCount}</span>
        </button>

        {/* Share */}
        <button className="flex flex-col items-center">
          <div className="w-12 h-12 flex items-center justify-center">
            <Share2 className="w-8 h-8 text-white" />
          </div>
          <span className="text-white text-xs font-semibold">{shareCount}</span>
        </button>

        {/* Save */}
        <button onClick={handleFavorite} className="flex flex-col items-center">
          <div className="w-12 h-12 flex items-center justify-center">
            <Bookmark className={cn(
              "w-8 h-8 transition-colors",
              isFav ? "text-yellow-500 fill-yellow-500" : "text-white"
            )} />
          </div>
        </button>

        {/* Music Disc */}
        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-gray-800 to-gray-900 border-2 border-gray-600 flex items-center justify-center animate-spin-slow">
          <div className="w-4 h-4 rounded-full bg-gray-600" />
        </div>
      </div>

      {/* Bottom Info */}
      <div className="absolute left-0 right-16 bottom-20 p-4 z-20">
        {/* Channel Name */}
        <div className="flex items-center gap-2 mb-2">
          <span className="text-white font-bold text-lg">@{currentVideo.animeSlug}</span>
          <Verified className="w-4 h-4 text-blue-400 fill-blue-400" />
        </div>

        {/* Description */}
        <p className="text-white text-sm mb-2 line-clamp-2">
          <span className="font-semibold">Episodio {currentVideo.episodeNumber}</span>
          {currentVideo.episodeTitle && ` - ${currentVideo.episodeTitle}`}
        </p>

        {/* Anime Title */}
        <p className="text-white text-sm font-medium mb-2">{currentVideo.animeTitle}</p>

        {/* Tags */}
        <div className="flex items-center gap-1 text-white text-sm">
          <Music className="w-4 h-4" />
          <span className="line-clamp-1">Música original - {currentVideo.animeTitle}</span>
        </div>
      </div>

      {/* Swipe Indicators */}
      {currentVideoIndex > 0 && swipeOffset < -30 && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-30">
          <div className="flex flex-col items-center gap-2 bg-black/50 backdrop-blur-md text-white px-4 py-2 rounded-full">
            <ChevronDown className="w-5 h-5 rotate-180" />
            <span className="text-sm font-medium">Anterior</span>
          </div>
        </div>
      )}

      {currentVideoIndex < videos.length - 1 && swipeOffset > 30 && (
        <div className="absolute bottom-32 left-1/2 -translate-x-1/2 z-30">
          <div className="flex flex-col items-center gap-2 bg-black/50 backdrop-blur-md text-white px-4 py-2 rounded-full">
            <ChevronDown className="w-5 h-5" />
            <span className="text-sm font-medium">Siguiente</span>
          </div>
        </div>
      )}

      {/* Progress Dots */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 flex flex-col gap-1.5 z-20">
        {videos.slice(
          Math.max(0, currentVideoIndex - 2),
          Math.min(videos.length, currentVideoIndex + 3)
        ).map((_, i) => {
          const actualIndex = Math.max(0, currentVideoIndex - 2) + i;
          return (
            <button
              key={actualIndex}
              onClick={() => onVideoChange(actualIndex)}
              className={cn(
                "rounded-full transition-all duration-300",
                actualIndex === currentVideoIndex
                  ? "w-2 h-6 bg-white shadow-lg"
                  : "w-2 h-2 bg-white/40 hover:bg-white/70"
              )}
            />
          );
        })}
      </div>

      {/* Video Counter */}
      <div className="absolute left-4 top-16 z-20">
        <div className="bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full">
          <span className="text-white text-sm font-medium">
            {currentVideoIndex + 1} / {videos.length}
          </span>
        </div>
      </div>

      {/* Tap to view anime */}
      <button
        onClick={() => onSelectAnime(currentVideo)}
        className="absolute left-4 top-28 z-20"
      >
        <div className="bg-pink-500/80 backdrop-blur-md px-4 py-2 rounded-full flex items-center gap-2">
          <Play className="w-4 h-4 text-white" />
          <span className="text-white text-sm font-medium">Ver episodios</span>
        </div>
      </button>

      {/* Swipe Hint */}
      {currentVideoIndex === 0 && !isSwiping && (
        <div className="absolute bottom-36 left-1/2 -translate-x-1/2 z-20 animate-bounce">
          <div className="flex flex-col items-center gap-1 text-white/70">
            <ChevronDown className="w-6 h-6" />
            <span className="text-xs">Desliza</span>
          </div>
        </div>
      )}
    </div>
  );
}
