'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { useStore } from '@/lib/store';
import {
  ArrowLeft,
  ThumbsUp,
  ThumbsDown,
  Share2,
  Bookmark,
  BookmarkCheck,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Settings,
  Maximize,
  Volume2,
  VolumeX,
  ChevronDown,
  Check,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Episode {
  id: string;
  number: number;
  title?: string;
}

interface AnimeInfo {
  id: string;
  title: string;
  synopsis: string;
  poster: string;
  banner?: string;
  slug: string;
  score: number;
  votes: number;
  episodes: Episode[];
  genres: string[];
  status: string;
  type: string;
  year: string;
}

interface Server {
  server: string;
  url: string;
}

interface EpisodeData {
  servers: {
    SUB: Server[];
    DUB: Server[];
  };
  episode: {
    number: number;
    title?: string;
  };
}

interface TikTokPlayerProps {
  anime: AnimeInfo;
  episode: Episode;
  episodeData: EpisodeData | null;
  selectedServer: Server | null;
  audioType: 'SUB' | 'DUB';
  loading: boolean;
  onServerChange: (server: Server) => void;
  onAudioTypeChange: (type: 'SUB' | 'DUB') => void;
  onEpisodeChange: (episode: Episode) => void;
  onBack: () => void;
}

export function TikTokPlayer({
  anime,
  episode,
  episodeData,
  selectedServer,
  audioType,
  loading,
  onServerChange,
  onAudioTypeChange,
  onEpisodeChange,
  onBack,
}: TikTokPlayerProps) {
  const [showControls, setShowControls] = useState(true);
  const [showServerMenu, setShowServerMenu] = useState(false);
  const [showPlaylist, setShowPlaylist] = useState(false);
  const controlsTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  const { isFavorite, addFavorite, removeFavorite, watchHistory } = useStore();
  const isFav = isFavorite(anime.slug);

  // Current episode index
  const currentEpisodeIndex = anime.episodes.findIndex(ep => ep.number === episode.number);
  const hasPrev = currentEpisodeIndex > 0;
  const hasNext = currentEpisodeIndex < anime.episodes.length - 1;

  // Hide controls after inactivity
  useEffect(() => {
    if (showControls && selectedServer) {
      controlsTimeoutRef.current = setTimeout(() => {
        setShowControls(false);
      }, 3000);
    }
    return () => {
      if (controlsTimeoutRef.current) {
        clearTimeout(controlsTimeoutRef.current);
      }
    };
  }, [showControls, selectedServer]);

  const handleFavorite = useCallback(() => {
    if (isFav) {
      removeFavorite(anime.slug);
    } else {
      addFavorite({
        slug: anime.slug,
        title: anime.title,
        poster: anime.poster,
        type: anime.type,
        score: anime.score,
      });
    }
  }, [isFav, anime, addFavorite, removeFavorite]);

  const handlePrevEpisode = useCallback(() => {
    if (hasPrev) {
      onEpisodeChange(anime.episodes[currentEpisodeIndex - 1]);
    }
  }, [hasPrev, currentEpisodeIndex, anime.episodes, onEpisodeChange]);

  const handleNextEpisode = useCallback(() => {
    if (hasNext) {
      onEpisodeChange(anime.episodes[currentEpisodeIndex + 1]);
    }
  }, [hasNext, currentEpisodeIndex, anime.episodes, onEpisodeChange]);

  const handleScreenTap = () => {
    setShowControls(true);
  };

  return (
    <div className="fixed inset-0 bg-black flex flex-col">
      {/* Header Overlay */}
      <div
        className={cn(
          "absolute top-0 left-0 right-0 z-30 transition-opacity duration-300",
          showControls ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
      >
        <div className="flex items-center justify-between p-4 bg-gradient-to-b from-black/80 to-transparent">
          <button
            onClick={onBack}
            className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 backdrop-blur-md"
          >
            <ArrowLeft className="w-5 h-5 text-white" />
          </button>
          
          <div className="flex-1 text-center px-4">
            <p className="text-white font-semibold text-sm truncate">{anime.title}</p>
            <p className="text-gray-400 text-xs">Episodio {episode.number}</p>
          </div>
          
          <button
            onClick={() => setShowServerMenu(!showServerMenu)}
            className="w-10 h-10 flex items-center justify-center rounded-full bg-white/10 backdrop-blur-md"
          >
            <Settings className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>

      {/* Video Player Area */}
      <div
        className="flex-1 relative"
        onClick={handleScreenTap}
      >
        {selectedServer ? (
          <iframe
            src={selectedServer.url}
            className="w-full h-full"
            allowFullScreen
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
            <div className="text-center">
              <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-4 animate-pulse">
                <Play className="w-8 h-8 text-white" />
              </div>
              <p className="text-gray-400">
                {loading ? 'Cargando servidor...' : 'Selecciona un servidor'}
              </p>
            </div>
          </div>
        )}

        {/* Episode Navigation Overlay */}
        <div
          className={cn(
            "absolute inset-x-0 bottom-24 flex justify-center gap-4 transition-opacity duration-300",
            showControls ? "opacity-100" : "opacity-0 pointer-events-none"
          )}
        >
          <button
            disabled={!hasPrev}
            onClick={(e) => {
              e.stopPropagation();
              handlePrevEpisode();
            }}
            className={cn(
              "w-14 h-14 rounded-full flex items-center justify-center backdrop-blur-md",
              hasPrev ? "bg-white/20" : "bg-white/5 opacity-50"
            )}
          >
            <SkipBack className="w-6 h-6 text-white" />
          </button>
          
          <button
            disabled={!hasNext}
            onClick={(e) => {
              e.stopPropagation();
              handleNextEpisode();
            }}
            className={cn(
              "w-14 h-14 rounded-full flex items-center justify-center backdrop-blur-md",
              hasNext ? "bg-white/20" : "bg-white/5 opacity-50"
            )}
          >
            <SkipForward className="w-6 h-6 text-white" />
          </button>
        </div>
      </div>

      {/* Bottom Controls */}
      <div
        className={cn(
          "absolute bottom-0 left-0 right-0 z-30 transition-opacity duration-300",
          showControls ? "opacity-100" : "opacity-0 pointer-events-none"
        )}
      >
        <div className="bg-gradient-to-t from-black/90 to-transparent p-4 pt-12">
          {/* Episode Info */}
          <div className="mb-4">
            <h2 className="text-white font-bold text-lg">
              Episodio {episode.number}
              {episode.title && `: ${episode.title}`}
            </h2>
            <p className="text-gray-400 text-sm">{anime.title}</p>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-around mb-4">
            <button className="flex flex-col items-center gap-1">
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                <ThumbsUp className="w-5 h-5 text-white" />
              </div>
              <span className="text-gray-400 text-xs">{Math.floor(Math.random() * 50 + 10)}K</span>
            </button>
            
            <button className="flex flex-col items-center gap-1">
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                <ThumbsDown className="w-5 h-5 text-white" />
              </div>
              <span className="text-gray-400 text-xs">No me gusta</span>
            </button>
            
            <button className="flex flex-col items-center gap-1">
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                <Share2 className="w-5 h-5 text-white" />
              </div>
              <span className="text-gray-400 text-xs">Compartir</span>
            </button>
            
            <button onClick={handleFavorite} className="flex flex-col items-center gap-1">
              <div className={cn(
                "w-12 h-12 rounded-full flex items-center justify-center",
                isFav ? "bg-pink-500/20" : "bg-white/10"
              )}>
                {isFav ? (
                  <BookmarkCheck className="w-5 h-5 text-pink-400" />
                ) : (
                  <Bookmark className="w-5 h-5 text-white" />
                )}
              </div>
              <span className="text-gray-400 text-xs">{isFav ? 'Guardado' : 'Guardar'}</span>
            </button>
            
            <button
              onClick={() => setShowPlaylist(true)}
              className="flex flex-col items-center gap-1"
            >
              <div className="w-12 h-12 rounded-full bg-white/10 flex items-center justify-center">
                <span className="text-white font-bold text-sm">{anime.episodes.length}</span>
              </div>
              <span className="text-gray-400 text-xs">Episodios</span>
            </button>
          </div>
        </div>
      </div>

      {/* Server Selection Modal */}
      {showServerMenu && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/50"
          onClick={() => setShowServerMenu(false)}
        >
          <div
            className="w-full max-w-lg bg-gray-900 rounded-t-3xl p-4 pb-8 animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-white font-bold text-lg">Configuración</h3>
              <button
                onClick={() => setShowServerMenu(false)}
                className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center"
              >
                <span className="text-white text-lg">×</span>
              </button>
            </div>

            {/* Audio Type */}
            {episodeData && (
              <div className="mb-4">
                <p className="text-gray-400 text-sm mb-2">Audio</p>
                <div className="flex gap-2">
                  {episodeData.servers.SUB?.length > 0 && (
                    <button
                      onClick={() => onAudioTypeChange('SUB')}
                      className={cn(
                        "flex-1 py-3 rounded-xl text-center font-medium transition-all",
                        audioType === 'SUB'
                          ? "bg-purple-600 text-white"
                          : "bg-white/10 text-gray-300"
                      )}
                    >
                      SUB
                    </button>
                  )}
                  {episodeData.servers.DUB?.length > 0 && (
                    <button
                      onClick={() => onAudioTypeChange('DUB')}
                      className={cn(
                        "flex-1 py-3 rounded-xl text-center font-medium transition-all",
                        audioType === 'DUB'
                          ? "bg-purple-600 text-white"
                          : "bg-white/10 text-gray-300"
                      )}
                    >
                      DUB
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Server Selection */}
            {episodeData && (
              <div>
                <p className="text-gray-400 text-sm mb-2">Servidor</p>
                <div className="space-y-2">
                  {episodeData.servers[audioType]?.map((server) => (
                    <button
                      key={server.server}
                      onClick={() => {
                        onServerChange(server);
                        setShowServerMenu(false);
                      }}
                      className={cn(
                        "w-full flex items-center justify-between p-3 rounded-xl transition-all",
                        selectedServer?.server === server.server
                          ? "bg-purple-600 text-white"
                          : "bg-white/10 text-gray-300 hover:bg-white/20"
                      )}
                    >
                      <span className="font-medium">{server.server}</span>
                      {selectedServer?.server === server.server && (
                        <Check className="w-5 h-5" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Playlist Modal */}
      {showPlaylist && (
        <div
          className="fixed inset-0 z-50 flex items-end justify-center bg-black/50"
          onClick={() => setShowPlaylist(false)}
        >
          <div
            className="w-full max-w-lg bg-gray-900 rounded-t-3xl animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="p-4 border-b border-white/10">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <img
                    src={anime.poster}
                    alt={anime.title}
                    className="w-12 h-12 rounded-lg object-cover"
                  />
                  <div>
                    <h3 className="text-white font-bold">{anime.title}</h3>
                    <p className="text-gray-400 text-sm">{anime.episodes.length} episodios</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowPlaylist(false)}
                  className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center"
                >
                  <span className="text-white text-lg">×</span>
                </button>
              </div>
            </div>

            {/* Episode List */}
            <ScrollArea className="h-[50vh]">
              <div className="p-2">
                {anime.episodes.map((ep) => {
                  const isCurrent = ep.number === episode.number;
                  const isWatched = watchHistory.some(
                    h => h.animeSlug === anime.slug && h.episodeNumber === ep.number
                  );

                  return (
                    <button
                      key={ep.id}
                      onClick={() => {
                        onEpisodeChange(ep);
                        setShowPlaylist(false);
                      }}
                      disabled={loading}
                      className={cn(
                        "w-full flex items-center gap-3 p-3 rounded-xl transition-all",
                        isCurrent ? "bg-purple-600/30" : "hover:bg-white/5"
                      )}
                    >
                      <div
                        className={cn(
                          "w-10 h-10 rounded-lg flex items-center justify-center font-bold",
                          isCurrent
                            ? "bg-purple-600 text-white"
                            : isWatched
                            ? "bg-green-500/20 text-green-400"
                            : "bg-white/10 text-gray-300"
                        )}
                      >
                        {isCurrent ? (
                          <Play className="w-4 h-4 fill-white" />
                        ) : (
                          ep.number
                        )}
                      </div>
                      <div className="flex-1 text-left">
                        <p
                          className={cn(
                            "font-medium",
                            isCurrent ? "text-purple-300" : "text-white"
                          )}
                        >
                          {ep.title || `Episodio ${ep.number}`}
                        </p>
                        <p className="text-gray-500 text-xs">
                          {Math.floor(Math.random() * 12 + 12)}:{Math.floor(Math.random() * 60).toString().padStart(2, '0')}
                          {isWatched && " • Visto"}
                        </p>
                      </div>
                    </button>
                  );
                })}
              </div>
            </ScrollArea>
          </div>
        </div>
      )}
    </div>
  );
}
