'use client';

import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { useStore } from '@/lib/store';
import {
  ThumbsUp,
  ThumbsDown,
  Share2,
  Bookmark,
  BookmarkCheck,
  MoreHorizontal,
  ChevronDown,
  ChevronUp,
  Play,
  Clock,
  Star,
  Eye,
  Calendar,
  CheckCircle2,
  ListVideo,
  SkipForward,
  SkipBack,
} from 'lucide-react';

interface Episode {
  id: string;
  number: number;
  title?: string;
}

interface AnimeInfo {
  id: string;
  title: string;
  synopsis: string;
  poster: string;
  banner?: string;
  slug: string;
  score: number;
  votes: number;
  episodes: Episode[];
  genres: string[];
  status: string;
  type: string;
  year: string;
}

interface Server {
  server: string;
  url: string;
}

interface EpisodeData {
  servers: {
    SUB: Server[];
    DUB: Server[];
  };
  episode: {
    number: number;
    title?: string;
  };
}

interface WatchPageProps {
  anime: AnimeInfo;
  episode: Episode;
  episodeData: EpisodeData | null;
  selectedServer: Server | null;
  audioType: 'SUB' | 'DUB';
  loading: boolean;
  onServerChange: (server: Server) => void;
  onAudioTypeChange: (type: 'SUB' | 'DUB') => void;
  onEpisodeChange: (episode: Episode) => void;
  relatedVideos: Array<{
    animeSlug: string;
    animeTitle: string;
    animePoster: string;
    episodeNumber: number;
    episodeTitle?: string;
  }>;
  onRelatedClick: (video: { animeSlug: string; animeTitle: string; animePoster: string }) => void;
}

export function WatchPage({
  anime,
  episode,
  episodeData,
  selectedServer,
  audioType,
  loading,
  onServerChange,
  onAudioTypeChange,
  onEpisodeChange,
  relatedVideos,
  onRelatedClick,
}: WatchPageProps) {
  const [descriptionExpanded, setDescriptionExpanded] = useState(false);
  const [showPlaylist, setShowPlaylist] = useState(true);
  const { isFavorite, addFavorite, removeFavorite, addToHistory, watchHistory } = useStore();
  
  const isFav = isFavorite(anime.slug);
  
  // Find current episode index
  const currentEpisodeIndex = anime.episodes.findIndex(ep => ep.number === episode.number);
  const hasPrev = currentEpisodeIndex > 0;
  const hasNext = currentEpisodeIndex < anime.episodes.length - 1;

  const handleFavorite = () => {
    if (isFav) {
      removeFavorite(anime.slug);
    } else {
      addFavorite({
        slug: anime.slug,
        title: anime.title,
        poster: anime.poster,
        type: anime.type,
        score: anime.score,
      });
    }
  };

  const handlePrevEpisode = () => {
    if (hasPrev) {
      onEpisodeChange(anime.episodes[currentEpisodeIndex - 1]);
    }
  };

  const handleNextEpisode = () => {
    if (hasNext) {
      onEpisodeChange(anime.episodes[currentEpisodeIndex + 1]);
    }
  };

  // Mock view count
  const viewCount = Math.floor(Math.random() * 500000 + 50000);
  const formattedViews = viewCount > 1000000 
    ? `${(viewCount / 1000000).toFixed(1)}M` 
    : `${Math.floor(viewCount / 1000)}K`;

  return (
    <div className="flex flex-col lg:flex-row gap-6 p-4 lg:p-6">
      {/* Left: Video Player & Info */}
      <div className="flex-1 min-w-0">
        {/* Video Player */}
        <div className="relative aspect-video bg-black rounded-xl overflow-hidden mb-4 group">
          {selectedServer ? (
            <iframe
              src={selectedServer.url}
              className="w-full h-full"
              allowFullScreen
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-900">
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-white/10 flex items-center justify-center mx-auto mb-4 animate-pulse">
                  <Play className="w-8 h-8 text-white" />
                </div>
                <p className="text-gray-400">
                  {loading ? 'Cargando servidor...' : 'Selecciona un servidor'}
                </p>
              </div>
            </div>
          )}
          
          {/* Episode Navigation Overlay */}
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="secondary"
              size="sm"
              disabled={!hasPrev}
              onClick={handlePrevEpisode}
              className="bg-black/60 hover:bg-black/80 text-white border-0"
            >
              <SkipBack className="w-4 h-4 mr-1" />
              Anterior
            </Button>
            <Button
              variant="secondary"
              size="sm"
              disabled={!hasNext}
              onClick={handleNextEpisode}
              className="bg-black/60 hover:bg-black/80 text-white border-0"
            >
              Siguiente
              <SkipForward className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>

        {/* Video Title */}
        <h1 className="text-xl lg:text-2xl font-bold text-white mb-3">
          {episode.title || `Episodio ${episode.number}`}
          <span className="text-gray-400 font-normal ml-2">- {anime.title}</span>
        </h1>

        {/* Channel Info & Actions */}
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4 pb-4 border-b border-white/10">
          {/* Channel Info */}
          <div className="flex items-center gap-4">
            <img
              src={anime.poster}
              alt={anime.title}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-white font-semibold">{anime.title}</h3>
                <CheckCircle2 className="w-4 h-4 text-gray-400" />
              </div>
              <p className="text-gray-400 text-sm">{Math.floor(Math.random() * 900 + 100)}K suscriptores</p>
            </div>
            <Button
              onClick={handleFavorite}
              variant={isFav ? 'secondary' : 'default'}
              className={cn(
                "rounded-full px-6",
                isFav ? "bg-gray-700 text-white hover:bg-gray-600" : "bg-purple-600 hover:bg-purple-700"
              )}
            >
              {isFav ? (
                <>
                  <BookmarkCheck className="w-4 h-4 mr-2" />
                  Suscrito
                </>
              ) : (
                <>
                  <Bookmark className="w-4 h-4 mr-2" />
                  Suscribirse
                </>
              )}
            </Button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2">
            {/* Server Selection */}
            {episodeData && (
              <div className="flex items-center gap-1 bg-white/10 rounded-full p-1 mr-2">
                {episodeData.servers.SUB?.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onAudioTypeChange('SUB')}
                    className={cn(
                      "rounded-full px-4",
                      audioType === 'SUB' && "bg-purple-600 text-white"
                    )}
                  >
                    SUB
                  </Button>
                )}
                {episodeData.servers.DUB?.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onAudioTypeChange('DUB')}
                    className={cn(
                      "rounded-full px-4",
                      audioType === 'DUB' && "bg-purple-600 text-white"
                    )}
                  >
                    DUB
                  </Button>
                )}
              </div>
            )}
            
            <div className="flex items-center bg-white/10 rounded-full">
              <Button variant="ghost" size="sm" className="rounded-r-none border-r border-white/10">
                <ThumbsUp className="w-4 h-4 mr-2" />
                {Math.floor(Math.random() * 50 + 10)}K
              </Button>
              <Button variant="ghost" size="sm" className="rounded-l-none">
                <ThumbsDown className="w-4 h-4" />
              </Button>
            </div>
            
            <Button variant="ghost" size="sm" className="bg-white/10 rounded-full">
              <Share2 className="w-4 h-4 mr-2" />
              Compartir
            </Button>
          </div>
        </div>

        {/* Server Selection (if multiple) */}
        {episodeData && episodeData.servers[audioType]?.length > 1 && (
          <div className="mb-4 p-3 bg-white/5 rounded-xl">
            <p className="text-sm text-gray-400 mb-2">Servidor:</p>
            <div className="flex flex-wrap gap-2">
              {episodeData.servers[audioType]?.map((server) => (
                <Button
                  key={server.server}
                  variant={selectedServer?.server === server.server ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => onServerChange(server)}
                  className={cn(
                    selectedServer?.server === server.server 
                      ? "bg-purple-600 hover:bg-purple-700" 
                      : "border-white/20 text-white hover:bg-white/10"
                  )}
                >
                  {server.server}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Description Box */}
        <div className={cn(
          "bg-white/5 rounded-xl p-4 transition-all",
          descriptionExpanded && "bg-white/10"
        )}>
          <div className="flex items-center gap-4 mb-2 text-sm text-gray-300">
            <span className="font-semibold text-white">{formattedViews} vistas</span>
            <span>•</span>
            <span>hace {Math.floor(Math.random() * 7 + 1)} días</span>
          </div>
          
          <div className={cn(
            "text-gray-300 text-sm overflow-hidden transition-all",
            descriptionExpanded ? "max-h-none" : "max-h-20"
          )}>
            <p className="mb-3">{anime.synopsis}</p>
            {anime.genres && (
              <div className="flex flex-wrap gap-2 mt-3">
                {anime.genres.map((genre) => (
                  <Badge key={genre} variant="secondary" className="bg-purple-500/20 text-purple-300">
                    {genre}
                  </Badge>
                ))}
              </div>
            )}
          </div>
          
          <button
            onClick={() => setDescriptionExpanded(!descriptionExpanded)}
            className="flex items-center gap-1 text-sm text-gray-400 hover:text-white mt-3 transition-colors"
          >
            {descriptionExpanded ? (
              <>
                Mostrar menos <ChevronUp className="w-4 h-4" />
              </>
            ) : (
              <>
                Mostrar más <ChevronDown className="w-4 h-4" />
              </>
            )}
          </button>
        </div>

        {/* Playlist Toggle (Mobile) */}
        <Button
          variant="outline"
          onClick={() => setShowPlaylist(!showPlaylist)}
          className="lg:hidden mt-4 w-full border-white/20 text-white"
        >
          <ListVideo className="w-4 h-4 mr-2" />
          {anime.episodes.length} episodios
          <ChevronDown className={cn("w-4 h-4 ml-2 transition-transform", showPlaylist && "rotate-180")} />
        </Button>
      </div>

      {/* Right: Playlist & Related */}
      <div className={cn(
        "lg:w-96 flex-shrink-0",
        !showPlaylist && "hidden lg:block"
      )}>
        {/* Playlist Panel */}
        <div className="bg-white/5 rounded-xl overflow-hidden">
          {/* Playlist Header */}
          <div className="p-3 bg-white/5 border-b border-white/10">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ListVideo className="w-5 h-5 text-purple-400" />
                <span className="font-semibold text-white">{anime.title}</span>
              </div>
              <Badge variant="secondary" className="bg-purple-500/20 text-purple-300">
                {anime.episodes.length} episodios
              </Badge>
            </div>
            <p className="text-xs text-gray-400 mt-1">
              Episodio {episode.number} de {anime.episodes.length}
            </p>
          </div>
          
          {/* Episode List */}
          <ScrollArea className="h-[300px] lg:h-[calc(100vh-350px)]">
            <div className="divide-y divide-white/5">
              {anime.episodes.map((ep) => {
                const isCurrent = ep.number === episode.number;
                const isWatched = watchHistory.some(
                  h => h.animeSlug === anime.slug && h.episodeNumber === ep.number
                );
                
                return (
                  <button
                    key={ep.id}
                    onClick={() => onEpisodeChange(ep)}
                    disabled={loading}
                    className={cn(
                      "w-full flex items-center gap-3 p-3 text-left hover:bg-white/10 transition-all",
                      isCurrent && "bg-purple-500/20 border-l-2 border-purple-500"
                    )}
                  >
                    {/* Number/Thumbnail */}
                    <div className={cn(
                      "w-10 h-10 rounded-lg flex items-center justify-center text-sm font-bold flex-shrink-0",
                      isCurrent ? "bg-purple-600 text-white" : 
                      isWatched ? "bg-gray-700 text-gray-300" : "bg-white/10 text-gray-300"
                    )}>
                      {isCurrent ? (
                        <Play className="w-4 h-4 fill-white" />
                      ) : (
                        ep.number
                      )}
                    </div>
                    
                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <p className={cn(
                        "text-sm font-medium truncate",
                        isCurrent ? "text-white" : "text-gray-300"
                      )}>
                        {ep.title || `Episodio ${ep.number}`}
                      </p>
                      <p className="text-xs text-gray-500">
                        {Math.floor(Math.random() * 12 + 12)}:{Math.floor(Math.random() * 60).toString().padStart(2, '0')}
                        {isWatched && " • Visto"}
                      </p>
                    </div>
                    
                    {/* Playing indicator */}
                    {isCurrent && (
                      <div className="flex gap-0.5">
                        <span className="w-1 h-4 bg-purple-500 rounded-full animate-pulse" />
                        <span className="w-1 h-4 bg-purple-500 rounded-full animate-pulse delay-75" />
                        <span className="w-1 h-4 bg-purple-500 rounded-full animate-pulse delay-150" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </ScrollArea>
        </div>

        {/* Related Videos */}
        {relatedVideos.length > 0 && (
          <div className="mt-4">
            <h3 className="text-white font-semibold mb-3">Videos relacionados</h3>
            <div className="space-y-2">
              {relatedVideos.slice(0, 5).map((video, index) => (
                <button
                  key={`${video.animeSlug}-${video.episodeNumber}-${index}`}
                  onClick={() => onRelatedClick(video)}
                  className="w-full flex gap-3 p-2 rounded-lg hover:bg-white/5 transition-colors group"
                >
                  <div className="relative w-40 aspect-video rounded-lg overflow-hidden flex-shrink-0">
                    <img
                      src={video.animePoster}
                      alt={video.animeTitle}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                    <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded">
                      {Math.floor(Math.random() * 12 + 12)}:{Math.floor(Math.random() * 60).toString().padStart(2, '0')}
                    </div>
                  </div>
                  <div className="flex-1 text-left min-w-0">
                    <p className="text-sm font-medium text-white line-clamp-2 group-hover:text-purple-400">
                      {video.episodeTitle || `Episodio ${video.episodeNumber}`}
                    </p>
                    <p className="text-xs text-gray-400 mt-1">{video.animeTitle}</p>
                    <p className="text-xs text-gray-500">
                      {Math.floor(Math.random() * 900 + 100)}K vistas
                    </p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
