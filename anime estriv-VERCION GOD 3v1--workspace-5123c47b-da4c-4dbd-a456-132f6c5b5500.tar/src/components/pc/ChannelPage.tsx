'use client';

import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import { useStore } from '@/lib/store';
import {
  Play,
  Star,
  Eye,
  Calendar,
  CheckCircle2,
  Bookmark,
  BookmarkCheck,
  Grid,
  List,
  Filter,
  SortAsc,
  Search,
  Info,
  Clock,
} from 'lucide-react';

interface Episode {
  id: string;
  number: number;
  title?: string;
}

interface AnimeInfo {
  id: string;
  title: string;
  synopsis: string;
  poster: string;
  banner?: string;
  slug: string;
  score: number;
  votes: number;
  episodes: Episode[];
  genres: string[];
  status: string;
  type: string;
  year: string;
}

interface ChannelPageProps {
  anime: AnimeInfo;
  loading: boolean;
  onPlayEpisode: (episode: Episode) => void;
  onBack: () => void;
}

export function ChannelPage({ anime, loading, onPlayEpisode, onBack }: ChannelPageProps) {
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [activeTab, setActiveTab] = useState<'videos' | 'about'>('videos');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'newest' | 'oldest' | 'popular'>('newest');
  
  const { isFavorite, addFavorite, removeFavorite, watchHistory } = useStore();
  const isFav = isFavorite(anime.slug);

  // Filter and sort episodes
  const filteredEpisodes = useMemo(() => {
    let eps = [...anime.episodes];
    
    // Search filter
    if (searchQuery) {
      eps = eps.filter(ep => 
        ep.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
        ep.number.toString().includes(searchQuery)
      );
    }
    
    // Sort
    switch (sortBy) {
      case 'oldest':
        eps.sort((a, b) => a.number - b.number);
        break;
      case 'newest':
        eps.sort((a, b) => b.number - a.number);
        break;
      default:
        break;
    }
    
    return eps;
  }, [anime.episodes, searchQuery, sortBy]);

  const handleFavorite = () => {
    if (isFav) {
      removeFavorite(anime.slug);
    } else {
      addFavorite({
        slug: anime.slug,
        title: anime.title,
        poster: anime.poster,
        type: anime.type,
        score: anime.score,
      });
    }
  };

  // Mock subscriber count
  const subscriberCount = Math.floor(Math.random() * 900 + 100);

  return (
    <div className="min-h-screen">
      {/* Channel Banner */}
      <div className="relative h-32 lg:h-48 bg-gradient-to-r from-purple-900/50 via-pink-900/30 to-red-900/50">
        {anime.banner && (
          <img
            src={anime.banner}
            alt=""
            className="absolute inset-0 w-full h-full object-cover opacity-40"
          />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-gray-950 to-transparent" />
      </div>

      {/* Channel Header */}
      <div className="relative px-4 lg:px-6 -mt-12 lg:-mt-16">
        <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-end">
          {/* Channel Avatar */}
          <img
            src={anime.poster}
            alt={anime.title}
            className="w-24 h-24 lg:w-32 lg:h-32 rounded-full border-4 border-gray-950 object-cover shadow-2xl"
          />
          
          {/* Channel Info */}
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-2xl lg:text-3xl font-bold text-white">{anime.title}</h1>
              <CheckCircle2 className="w-5 h-5 text-gray-400" />
            </div>
            
            <div className="flex flex-wrap items-center gap-3 text-gray-400 text-sm mb-3">
              <span>@{anime.slug}</span>
              <span>•</span>
              <span>{subscriberCount}K suscriptores</span>
              <span>•</span>
              <span>{anime.episodes.length} videos</span>
            </div>
            
            {/* Quick Stats */}
            <div className="flex flex-wrap gap-2">
              {anime.score > 0 && (
                <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-500/30">
                  <Star className="w-3 h-3 mr-1 fill-yellow-400" />
                  {anime.score.toFixed(1)}
                </Badge>
              )}
              <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30">
                {anime.type}
              </Badge>
              {anime.year && (
                <Badge className="bg-blue-500/20 text-blue-300 border-blue-500/30">
                  <Calendar className="w-3 h-3 mr-1" />
                  {anime.year}
                </Badge>
              )}
              <Badge className="bg-green-500/20 text-green-300 border-green-500/30">
                {anime.status}
              </Badge>
            </div>
          </div>
          
          {/* Subscribe Button */}
          <div className="flex items-center gap-2">
            <Button
              onClick={handleFavorite}
              variant={isFav ? 'secondary' : 'default'}
              size="lg"
              className={cn(
                "rounded-full px-8",
                isFav ? "bg-gray-700 text-white hover:bg-gray-600" : "bg-purple-600 hover:bg-purple-700"
              )}
            >
              {isFav ? (
                <>
                  <BookmarkCheck className="w-5 h-5 mr-2" />
                  Suscrito
                </>
              ) : (
                <>
                  <Bookmark className="w-5 h-5 mr-2" />
                  Suscribirse
                </>
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="border-b border-white/10 mt-6">
        <div className="px-4 lg:px-6 flex items-center gap-1">
          <button
            onClick={() => setActiveTab('videos')}
            className={cn(
              "px-4 py-3 text-sm font-medium border-b-2 transition-colors",
              activeTab === 'videos'
                ? "text-white border-purple-500"
                : "text-gray-400 border-transparent hover:text-gray-200"
            )}
          >
            Videos
          </button>
          <button
            onClick={() => setActiveTab('about')}
            className={cn(
              "px-4 py-3 text-sm font-medium border-b-2 transition-colors",
              activeTab === 'about'
                ? "text-white border-purple-500"
                : "text-gray-400 border-transparent hover:text-gray-200"
            )}
          >
            Información
          </button>
        </div>
      </div>

      {/* Tab Content */}
      <div className="p-4 lg:p-6">
        {activeTab === 'videos' && (
          <div>
            {/* Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
              {/* Search */}
              <div className="relative flex-1 max-w-xs">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Buscar episodios..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                />
              </div>
              
              <div className="flex items-center gap-2">
                {/* Sort */}
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as 'newest' | 'oldest' | 'popular')}
                  className="bg-white/5 border border-white/10 text-white text-sm rounded-lg px-3 py-2"
                >
                  <option value="newest">Más recientes</option>
                  <option value="oldest">Más antiguos</option>
                </select>
                
                {/* View Mode */}
                <div className="flex items-center bg-white/5 rounded-lg p-1">
                  <button
                    onClick={() => setViewMode('grid')}
                    className={cn(
                      "p-2 rounded-md transition-colors",
                      viewMode === 'grid' ? "bg-white/10 text-white" : "text-gray-400 hover:text-white"
                    )}
                  >
                    <Grid className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setViewMode('list')}
                    className={cn(
                      "p-2 rounded-md transition-colors",
                      viewMode === 'list' ? "bg-white/10 text-white" : "text-gray-400 hover:text-white"
                    )}
                  >
                    <List className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* Episodes Grid/List */}
            {filteredEpisodes.length > 0 ? (
              <div className={cn(
                viewMode === 'grid' 
                  ? "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4"
                  : "space-y-2"
              )}>
                {filteredEpisodes.map((ep) => {
                  const isWatched = watchHistory.some(
                    h => h.animeSlug === anime.slug && h.episodeNumber === ep.number
                  );
                  
                  if (viewMode === 'list') {
                    return (
                      <button
                        key={ep.id}
                        onClick={() => onPlayEpisode(ep)}
                        disabled={loading}
                        className="w-full flex items-center gap-4 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-all group text-left"
                      >
                        <div className="relative w-40 aspect-video rounded-lg overflow-hidden flex-shrink-0">
                          <img
                            src={anime.poster}
                            alt={`Episodio ${ep.number}`}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <Play className="w-8 h-8 text-white" />
                          </div>
                          <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded">
                            {Math.floor(Math.random() * 12 + 12)}:{Math.floor(Math.random() * 60).toString().padStart(2, '0')}
                          </div>
                          {isWatched && (
                            <div className="absolute top-1 right-1 bg-green-500 text-white text-xs px-1.5 py-0.5 rounded">
                              Visto
                            </div>
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="text-white font-medium mb-1 group-hover:text-purple-400 transition-colors">
                            {ep.title || `Episodio ${ep.number}`}
                          </h3>
                          <p className="text-gray-400 text-sm">{anime.title}</p>
                          <div className="flex items-center gap-2 text-gray-500 text-xs mt-1">
                            <Eye className="w-3 h-3" />
                            <span>{Math.floor(Math.random() * 900 + 100)}K vistas</span>
                            <span>•</span>
                            <span>hace {Math.floor(Math.random() * 30 + 1)} días</span>
                          </div>
                        </div>
                      </button>
                    );
                  }
                  
                  return (
                    <button
                      key={ep.id}
                      onClick={() => onPlayEpisode(ep)}
                      disabled={loading}
                      className="group text-left"
                    >
                      <div className="relative aspect-video rounded-xl overflow-hidden mb-2">
                        <img
                          src={anime.poster}
                          alt={`Episodio ${ep.number}`}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                          <div className="w-12 h-12 bg-black/60 rounded-full flex items-center justify-center">
                            <Play className="w-6 h-6 text-white" />
                          </div>
                        </div>
                        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded font-medium">
                          {Math.floor(Math.random() * 12 + 12)}:{Math.floor(Math.random() * 60).toString().padStart(2, '0')}
                        </div>
                        {isWatched && (
                          <div className="absolute top-2 right-2 bg-green-500/80 text-white text-xs px-1.5 py-0.5 rounded font-medium">
                            Visto
                          </div>
                        )}
                        <div className="absolute bottom-2 left-2 bg-purple-600/90 text-white text-sm px-2 py-1 rounded font-bold">
                          EP {ep.number}
                        </div>
                      </div>
                      <h3 className="text-white text-sm font-medium line-clamp-2 group-hover:text-purple-400 transition-colors">
                        {ep.title || `Episodio ${ep.number}`}
                      </h3>
                      <div className="flex items-center gap-2 text-gray-500 text-xs mt-1">
                        <span>{Math.floor(Math.random() * 900 + 100)}K vistas</span>
                        <span>•</span>
                        <span>hace {Math.floor(Math.random() * 30 + 1)} días</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16">
                <Search className="w-12 h-12 text-gray-600 mx-auto mb-4" />
                <p className="text-gray-400">No se encontraron episodios</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'about' && (
          <div className="max-w-3xl">
            <div className="bg-white/5 rounded-xl p-6 mb-6">
              <h2 className="text-lg font-semibold text-white mb-4">Descripción</h2>
              <p className="text-gray-300 leading-relaxed">{anime.synopsis}</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white/5 rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Detalles</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Tipo</span>
                    <span className="text-white">{anime.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Estado</span>
                    <span className="text-white">{anime.status}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Año</span>
                    <span className="text-white">{anime.year}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Episodios</span>
                    <span className="text-white">{anime.episodes.length}</span>
                  </div>
                  {anime.score > 0 && (
                    <div className="flex justify-between items-center">
                      <span className="text-gray-400">Puntuación</span>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-white">{anime.score.toFixed(1)}</span>
                        <span className="text-gray-500 text-sm">({anime.votes} votos)</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              
              {anime.genres && anime.genres.length > 0 && (
                <div className="bg-white/5 rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-white mb-4">Géneros</h3>
                  <div className="flex flex-wrap gap-2">
                    {anime.genres.map((genre) => (
                      <Badge
                        key={genre}
                        variant="secondary"
                        className="bg-purple-500/20 text-purple-300 hover:bg-purple-500/30"
                      >
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
            
            {/* Stats */}
            <div className="bg-white/5 rounded-xl p-6 mt-6">
              <h3 className="text-lg font-semibold text-white mb-4">Estadísticas</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-white">{anime.episodes.length}</p>
                  <p className="text-gray-400 text-sm">Videos</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-white">{subscriberCount}K</p>
                  <p className="text-gray-400 text-sm">Suscriptores</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-white">{Math.floor(Math.random() * 50 + 10)}M</p>
                  <p className="text-gray-400 text-sm">Vistas totales</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-white">{anime.year}</p>
                  <p className="text-gray-400 text-sm">Estreno</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
