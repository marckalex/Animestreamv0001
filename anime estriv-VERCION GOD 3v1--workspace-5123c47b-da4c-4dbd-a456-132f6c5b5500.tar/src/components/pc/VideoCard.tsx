'use client';

import { cn } from '@/lib/utils';
import { useStore } from '@/lib/store';
import { Clock, MoreVertical, Check, Heart, Share2, BookmarkPlus } from 'lucide-react';
import { useState } from 'react';

interface VideoCardProps {
  video: {
    animeSlug: string;
    animeTitle: string;
    animePoster: string;
    episodeNumber: number;
    episodeTitle?: string;
    views?: string;
    uploadedAt?: string;
    duration?: string;
    isWatched?: boolean;
    isLive?: boolean;
  };
  onClick: () => void;
  variant?: 'grid' | 'list';
  showChannel?: boolean;
}

export function VideoCard({ video, onClick, variant = 'grid', showChannel = true }: VideoCardProps) {
  const [showMenu, setShowMenu] = useState(false);
  const { isFavorite, addFavorite, removeFavorite, watchHistory } = useStore();
  
  const isFav = isFavorite(video.animeSlug);
  
  // Check if this episode was watched
  const watchProgress = watchHistory.find(
    h => h.animeSlug === video.animeSlug && h.episodeNumber === video.episodeNumber
  );
  
  const progressPercent = watchProgress ? Math.min(95, (watchProgress.timestamp / 1440) * 100) : 0;

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isFav) {
      removeFavorite(video.animeSlug);
    } else {
      addFavorite({
        slug: video.animeSlug,
        title: video.animeTitle,
        poster: video.animePoster,
      });
    }
  };

  if (variant === 'list') {
    return (
      <div 
        onClick={onClick}
        className="flex gap-3 p-2 rounded-lg hover:bg-white/5 cursor-pointer group"
      >
        {/* Thumbnail */}
        <div className="relative w-40 aspect-video rounded-lg overflow-hidden flex-shrink-0">
          <img
            src={video.animePoster}
            alt={video.animeTitle}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded font-medium">
            {video.duration || `${Math.floor(Math.random() * 12 + 12)}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`}
          </div>
          {progressPercent > 0 && (
            <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-600">
              <div className="h-full bg-red-500" style={{ width: `${progressPercent}%` }} />
            </div>
          )}
        </div>
        
        {/* Info */}
        <div className="flex-1 min-w-0">
          <h3 className="text-white text-sm font-medium line-clamp-2 mb-1 group-hover:text-purple-400 transition-colors">
            {video.episodeTitle || `Episodio ${video.episodeNumber}`}
          </h3>
          <p className="text-gray-400 text-xs mb-1">{video.animeTitle}</p>
          <div className="flex items-center gap-2 text-gray-500 text-xs">
            <span>{video.views || `${Math.floor(Math.random() * 900 + 100)}K vistas`}</span>
            <span>•</span>
            <span>{video.uploadedAt || 'hace 1 día'}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div 
      onClick={onClick}
      className="group cursor-pointer"
    >
      {/* Thumbnail */}
      <div className="relative aspect-video rounded-xl overflow-hidden mb-3">
        <img
          src={video.animePoster}
          alt={video.animeTitle}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        
        {/* Duration Badge */}
        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded font-medium">
          {video.duration || `${Math.floor(Math.random() * 12 + 12)}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`}
        </div>
        
        {/* Live Badge */}
        {video.isLive && (
          <div className="absolute top-2 left-2 bg-red-600 text-white text-xs px-2 py-0.5 rounded font-bold uppercase">
            EN VIVO
          </div>
        )}
        
        {/* Watched Badge */}
        {video.isWatched && (
          <div className="absolute top-2 right-2 bg-purple-600 text-white text-xs px-2 py-0.5 rounded flex items-center gap-1">
            <Check className="w-3 h-3" />
            Visto
          </div>
        )}
        
        {/* Progress Bar */}
        {progressPercent > 0 && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-600">
            <div className="h-full bg-red-500" style={{ width: `${progressPercent}%` }} />
          </div>
        )}
        
        {/* Hover Overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center">
          <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center w-14 h-14 bg-black/60 rounded-full">
            <svg className="w-8 h-8 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
              <path d="M8 5v14l11-7z" />
            </svg>
          </div>
        </div>
        
        {/* Quick Actions - appear on hover */}
        <div className="absolute top-2 right-2 flex flex-col gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowMenu(!showMenu);
            }}
            className="w-8 h-8 bg-black/60 rounded-full flex items-center justify-center hover:bg-black/80 transition-colors"
          >
            <MoreVertical className="w-4 h-4 text-white" />
          </button>
        </div>
      </div>

      {/* Video Info */}
      <div className="flex gap-3">
        {/* Channel Avatar (smaller) */}
        {showChannel && (
          <div className="flex-shrink-0">
            <img
              src={video.animePoster}
              alt={video.animeTitle}
              className="w-9 h-9 rounded-full object-cover"
            />
          </div>
        )}
        
        <div className="flex-1 min-w-0">
          {/* Title */}
          <h3 className="text-white text-sm font-medium line-clamp-2 mb-1 group-hover:text-purple-400 transition-colors">
            {video.episodeTitle || `Episodio ${video.episodeNumber}`}
          </h3>
          
          {/* Channel Name */}
          {showChannel && (
            <div className="flex items-center gap-1 text-gray-400 text-xs mb-0.5 hover:text-gray-300">
              <span className="hover:text-white cursor-pointer">{video.animeTitle}</span>
              <svg className="w-3.5 h-3.5 text-gray-400" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
              </svg>
            </div>
          )}
          
          {/* Views & Time */}
          <div className="flex items-center gap-2 text-gray-500 text-xs">
            <span>{video.views || `${Math.floor(Math.random() * 900 + 100)}K vistas`}</span>
            <span>•</span>
            <span>{video.uploadedAt || 'hace 1 día'}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
