'use client';

import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';
import {
  Search,
  Menu,
  X,
  Bell,
  User,
  Film,
  Mic,
  Sun,
  Moon
} from 'lucide-react';
import { useState } from 'react';
import { useStore } from '@/lib/store';

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onSearch: (e: React.FormEvent) => void;
  onToggleSidebar: () => void;
  isSidebarOpen: boolean;
  onHome: () => void;
}

export function Header({
  searchQuery,
  onSearchChange,
  onSearch,
  onToggleSidebar,
  isSidebarOpen,
  onHome
}: HeaderProps) {
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const { isDarkMode, toggleDarkMode } = useStore();

  return (
    <header className="fixed top-0 left-0 right-0 h-14 bg-gray-950/95 backdrop-blur-xl border-b border-white/10 z-50">
      <div className="flex items-center justify-between h-full px-4">
        {/* Left Section */}
        <div className="flex items-center gap-4">
          {/* Menu Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={onToggleSidebar}
            className={cn(
              "hidden md:flex transition-transform duration-200 hover:bg-white/10 rounded-full text-white",
              !isSidebarOpen && "rotate-180"
            )}
          >
            <Menu className="w-5 h-5" />
          </Button>

          {/* Logo */}
          <button
            onClick={onHome}
            className="flex items-center gap-2 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 flex items-center justify-center shadow-lg group-hover:shadow-purple-500/25 transition-shadow">
              <Film className="w-5 h-5 text-white" />
            </div>
            <span className="hidden sm:block font-bold text-lg">
              <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent">
                Anime
              </span>
              <span className="text-white">Stream</span>
            </span>
          </button>
        </div>

        {/* Center - Search Bar */}
        <div className={cn(
          "flex-1 max-w-2xl mx-4 transition-all duration-300",
          isSearchFocused && "max-w-3xl"
        )}>
          <form onSubmit={onSearch} className="flex items-center">
            <div className={cn(
              "flex-1 flex items-center border rounded-l-full transition-all",
              isSearchFocused
                ? "border-purple-500 bg-gray-900 shadow-lg shadow-purple-500/10"
                : "border-white/20 bg-gray-900"
            )}>
              <Input
                type="text"
                placeholder="Buscar anime..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                onBlur={() => setIsSearchFocused(false)}
                className="w-full pl-5 pr-4 py-2.5 bg-transparent border-0 focus-visible:ring-0 text-sm text-white placeholder:text-gray-400"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => onSearchChange('')}
                  className="p-2 hover:bg-white/10 transition-colors"
                >
                  <X className="w-4 h-4 text-gray-400" />
                </button>
              )}
            </div>

            <button
              type="submit"
              className={cn(
                "px-5 py-2.5 bg-white/10 border border-l-0 border-white/20 rounded-r-full hover:bg-white/20 transition-colors",
                isSearchFocused && "bg-white/15"
              )}
            >
              <Search className="w-5 h-5 text-gray-300" />
            </button>

            <Button
              variant="ghost"
              size="icon"
              className="ml-3 rounded-full hidden sm:flex hover:bg-white/10 text-white"
            >
              <Mic className="w-5 h-5" />
            </Button>
          </form>
        </div>

        {/* Right Section */}
        <div className="flex items-center gap-1 md:gap-2">
          {/* Dark Mode Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleDarkMode}
            className="rounded-full hover:bg-white/10 text-white"
          >
            {isDarkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </Button>

          {/* Notifications */}
          <Button
            variant="ghost"
            size="icon"
            className="relative rounded-full hover:bg-white/10 text-white"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full border-2 border-gray-950" />
          </Button>

          {/* User Avatar */}
          <Button
            variant="ghost"
            className="rounded-full hover:bg-white/10 p-0.5 ml-1"
          >
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
          </Button>
        </div>
      </div>
    </header>
  );
}
