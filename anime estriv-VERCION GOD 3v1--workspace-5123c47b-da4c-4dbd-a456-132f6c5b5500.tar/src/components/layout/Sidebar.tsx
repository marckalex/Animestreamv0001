'use client';

import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import {
  Home,
  Clock,
  Heart,
  Film,
  History,
  Flame,
  PlayCircle,
  Library,
  Bookmark,
  TrendingUp,
  X
} from 'lucide-react';
import { useState } from 'react';

interface SidebarProps {
  isOpen: boolean;
  onToggle: () => void;
  onHome: () => void;
  favorites: Array<{
    slug: string;
    title: string;
    poster: string;
    type?: string;
    score?: number;
  }>;
  onQuickSearch: (term: string) => void;
  searchHistory: string[];
}

const mainMenuItems = [
  { id: 'home', icon: Home, label: 'Inicio' },
  { id: 'trending', icon: Flame, label: 'Tendencias' },
  { id: 'subscriptions', icon: PlayCircle, label: 'Suscripciones' },
  { id: 'library', icon: Library, label: 'Biblioteca' },
];

const exploreItems = [
  { id: 'recent', icon: Clock, label: 'Recientes' },
  { id: 'liked', icon: Heart, label: 'Favoritos' },
  { id: 'history', icon: History, label: 'Historial' },
];

const genres = [
  'Acción', 'Romance', 'Comedia', 'Drama', 
  'Fantasía', 'Terror', 'Aventura', 'Ciencia Ficción'
];

export function Sidebar({ 
  isOpen, 
  onToggle, 
  onHome,
  favorites,
  onQuickSearch,
  searchHistory
}: SidebarProps) {
  const [activeTab, setActiveTab] = useState('home');
  const [showAllFavorites, setShowAllFavorites] = useState(false);

  const displayedFavorites = showAllFavorites ? favorites : favorites.slice(0, 5);

  return (
    <aside
      className={cn(
        "hidden md:flex flex-col fixed left-0 top-0 h-full bg-gray-950 border-r border-white/10 transition-all duration-300 z-40",
        isOpen ? "w-64" : "w-0 overflow-hidden"
      )}
    >
      <div className="flex flex-col h-full pt-14">
        {/* Logo */}
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 flex items-center justify-center shadow-lg">
              <Film className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold">
                <span className="bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent">
                  Anime
                </span>
                <span className="text-white">Stream</span>
              </h1>
              <p className="text-xs text-gray-400">Tu plataforma de anime</p>
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <ScrollArea className="flex-1">
          <div className="py-2">
            {/* Main Menu */}
            <div className="px-2 mb-2">
              {mainMenuItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    if (item.id === 'home') onHome();
                  }}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all",
                    activeTab === item.id
                      ? "bg-purple-500/20 text-purple-400 font-medium"
                      : "hover:bg-white/10 text-gray-300"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </button>
              ))}
            </div>

            {/* Divider */}
            <div className="mx-3 my-2 h-px bg-white/10" />

            {/* Explore Section */}
            <div className="px-2 mb-2">
              <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-1">
                Explorar
              </h3>
              {exploreItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={cn(
                    "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all",
                    activeTab === item.id
                      ? "bg-purple-500/20 text-purple-400 font-medium"
                      : "hover:bg-white/10 text-gray-300"
                  )}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </button>
              ))}
            </div>

            {/* Divider */}
            <div className="mx-3 my-2 h-px bg-white/10" />

            {/* Favorites */}
            {favorites.length > 0 && (
              <div className="px-2 mb-2">
                <div className="flex items-center justify-between px-3 mb-2">
                  <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider flex items-center gap-2">
                    <Bookmark className="w-3 h-3" />
                    Favoritos
                  </h3>
                  {favorites.length > 5 && (
                    <button
                      onClick={() => setShowAllFavorites(!showAllFavorites)}
                      className="text-xs text-purple-400 hover:text-purple-300"
                    >
                      {showAllFavorites ? 'Menos' : `Ver todos (${favorites.length})`}
                    </button>
                  )}
                </div>
                <div className="space-y-1">
                  {displayedFavorites.map((anime) => (
                    <button
                      key={anime.slug}
                      onClick={() => {
                        // Quick access - could trigger search or direct navigation
                        onQuickSearch(anime.title);
                      }}
                      className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-white/10 transition-all group"
                    >
                      <img
                        src={anime.poster}
                        alt={anime.title}
                        className="w-10 h-14 object-cover rounded-lg"
                        loading="lazy"
                      />
                      <div className="flex-1 text-left overflow-hidden">
                        <p className="text-sm font-medium text-gray-200 truncate group-hover:text-purple-400">
                          {anime.title}
                        </p>
                        {anime.type && (
                          <p className="text-xs text-gray-500">{anime.type}</p>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Recent Searches */}
            {searchHistory.length > 0 && (
              <div className="px-2 mb-2">
                <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
                  Búsquedas recientes
                </h3>
                <div className="flex flex-wrap gap-2 px-3">
                  {searchHistory.slice(0, 5).map((term) => (
                    <button
                      key={term}
                      onClick={() => onQuickSearch(term)}
                      className="bg-white/10 hover:bg-white/20 text-gray-300 text-xs px-3 py-1.5 rounded-full transition-colors"
                    >
                      {term}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Divider */}
            <div className="mx-3 my-2 h-px bg-white/10" />

            {/* Categories */}
            <div className="px-2">
              <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider px-3 mb-2">
                Categorías
              </h3>
              {genres.map((genre) => (
                <button
                  key={genre}
                  onClick={() => onQuickSearch(genre)}
                  className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm hover:bg-white/10 text-gray-300 transition-all"
                >
                  {genre}
                </button>
              ))}
            </div>
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="p-3 border-t border-white/10">
          <p className="text-xs text-gray-500 text-center">AnimeStream © 2024</p>
        </div>
      </div>
    </aside>
  );
}
