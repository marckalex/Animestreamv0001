'use client';

import { AnimeCard } from './AnimeCard';
import { useState } from 'react';
import { cn } from '@/lib/utils';

interface Anime {
  slug: string;
  title: string;
  poster: string;
  year?: string;
  type?: string;
  score?: number;
}

interface VideoGridProps {
  animes: Anime[];
  onSelectAnime: (anime: Anime) => void;
  title?: string;
}

const categories = [
  { id: 'all', label: 'Todos', icon: '🎬' },
  { id: 'tv', label: 'Series', icon: '📺' },
  { id: 'movie', label: 'Películas', icon: '🎥' },
  { id: 'ova', label: 'OVAs', icon: '💿' },
  { id: 'special', label: 'Especiales', icon: '⭐' },
];

export function VideoGrid({ animes, onSelectAnime, title = "Resultados" }: VideoGridProps) {
  const [activeCategory, setActiveCategory] = useState('all');

  // Filter by category
  const filteredAnimes = activeCategory === 'all'
    ? animes
    : animes.filter(a => a.type?.toLowerCase().includes(activeCategory));

  return (
    <div className="min-h-screen">
      {/* Category Chips */}
      <div className="sticky top-14 z-30 bg-gray-950/95 backdrop-blur-xl border-b border-white/10">
        <div className="flex items-center gap-2 px-4 md:px-6 py-3 overflow-x-auto scrollbar-hide">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={cn(
                "flex items-center gap-1.5 px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all duration-200",
                activeCategory === category.id
                  ? "bg-white text-black shadow-md"
                  : "bg-white/10 hover:bg-white/20 text-white"
              )}
            >
              <span>{category.icon}</span>
              <span>{category.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 md:p-6">
        {/* Header */}
        <div className="mb-6">
          <h2 className="text-xl font-bold text-white">{title}</h2>
          <p className="text-gray-400 text-sm mt-1">
            {filteredAnimes.length} resultados encontrados
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-x-4 gap-y-6">
          {filteredAnimes.map((anime) => (
            <AnimeCard
              key={anime.slug}
              anime={anime}
              onClick={() => onSelectAnime(anime)}
              variant="grid"
            />
          ))}
        </div>

        {/* Empty State */}
        {filteredAnimes.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20">
            <div className="w-24 h-24 rounded-full bg-gradient-to-br from-purple-500/20 to-pink-500/20 flex items-center justify-center mb-6">
              <span className="text-5xl">📺</span>
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">No hay resultados</h3>
            <p className="text-gray-400 text-center max-w-md">
              No se encontraron animes en esta categoría
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
