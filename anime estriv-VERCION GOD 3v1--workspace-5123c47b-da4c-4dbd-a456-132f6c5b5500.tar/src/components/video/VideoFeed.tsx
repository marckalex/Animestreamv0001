'use client';

import { useRef, useState, useCallback, useEffect, useMemo } from 'react';
import { AnimeCard } from './AnimeCard';
import { cn } from '@/lib/utils';
import { ChevronUp, ChevronDown } from 'lucide-react';

interface Anime {
  slug: string;
  title: string;
  poster: string;
  year?: string;
  type?: string;
  score?: number;
}

interface VideoFeedProps {
  animes: Anime[];
  currentAnime: Anime | null;
  onSelectAnime: (anime: Anime) => void;
}

export function VideoFeed({
  animes,
  currentAnime,
  onSelectAnime
}: VideoFeedProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const touchStartY = useRef(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const [swipeOffset, setSwipeOffset] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);

  // Calculate current index
  const currentIndex = useMemo(() => {
    if (!currentAnime) return 0;
    const index = animes.findIndex(a => a.slug === currentAnime.slug);
    return index !== -1 ? index : 0;
  }, [currentAnime, animes]);

  // Touch handlers
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    setIsSwiping(true);
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isSwiping || isTransitioning) return;
    const diff = touchStartY.current - e.touches[0].clientY;
    setSwipeOffset(Math.max(-200, Math.min(200, diff)));
  }, [isSwiping, isTransitioning]);

  const goToNext = useCallback(() => {
    if (currentIndex < animes.length - 1 && !isTransitioning) {
      setIsTransitioning(true);
      onSelectAnime(animes[currentIndex + 1]);
      setTimeout(() => setIsTransitioning(false), 400);
    }
  }, [currentIndex, animes, onSelectAnime, isTransitioning]);

  const goToPrev = useCallback(() => {
    if (currentIndex > 0 && !isTransitioning) {
      setIsTransitioning(true);
      onSelectAnime(animes[currentIndex - 1]);
      setTimeout(() => setIsTransitioning(false), 400);
    }
  }, [currentIndex, animes, onSelectAnime, isTransitioning]);

  const handleTouchEnd = useCallback(() => {
    setIsSwiping(false);
    if (swipeOffset > 80) {
      goToNext();
    } else if (swipeOffset < -80) {
      goToPrev();
    }
    setSwipeOffset(0);
  }, [swipeOffset, goToNext, goToPrev]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp') goToPrev();
      else if (e.key === 'ArrowDown') goToNext();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [goToNext, goToPrev]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 bg-black overflow-hidden touch-none"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Video Container */}
      <div
        className={cn(
          "absolute inset-0 transition-all ease-out",
          isSwiping ? "duration-0" : "duration-400"
        )}
        style={{ transform: `translateY(${-swipeOffset * 0.5}px)` }}
      >
        {/* Previous */}
        {currentIndex > 0 && (
          <div
            className="absolute inset-0 -translate-y-full"
            style={{
              opacity: swipeOffset < 0 ? Math.min(1, Math.abs(swipeOffset) / 100) : 0,
            }}
          >
            <AnimeCard
              anime={animes[currentIndex - 1]}
              onClick={() => {}}
              variant="feed"
            />
          </div>
        )}

        {/* Current */}
        {currentAnime && (
          <div
            className="absolute inset-0"
            style={{ scale: isSwiping ? Math.max(0.95, 1 - Math.abs(swipeOffset) / 800) : 1 }}
          >
            <AnimeCard
              anime={currentAnime}
              onClick={() => onSelectAnime(currentAnime)}
              variant="feed"
            />
          </div>
        )}

        {/* Next */}
        {currentIndex < animes.length - 1 && (
          <div
            className="absolute inset-0 translate-y-full"
            style={{
              opacity: swipeOffset > 0 ? Math.min(1, swipeOffset / 100) : 0,
            }}
          >
            <AnimeCard
              anime={animes[currentIndex + 1]}
              onClick={() => {}}
              variant="feed"
            />
          </div>
        )}
      </div>

      {/* Swipe Indicator */}
      {isSwiping && Math.abs(swipeOffset) > 30 && (
        <div className="absolute left-1/2 -translate-x-1/2 top-8 z-30">
          <div className={cn(
            "flex items-center gap-2 bg-black/60 backdrop-blur-md text-white text-sm px-4 py-2 rounded-full font-medium",
          )}>
            {swipeOffset > 0 ? (
              <>
                <ChevronDown className="w-4 h-4" />
                <span>Siguiente</span>
              </>
            ) : (
              <>
                <ChevronUp className="w-4 h-4" />
                <span>Anterior</span>
              </>
            )}
          </div>
        </div>
      )}

      {/* Navigation Dots */}
      <div className="absolute right-3 top-1/2 -translate-y-1/2 flex flex-col gap-2 z-20">
        {animes.slice(Math.max(0, currentIndex - 2), currentIndex + 3).map((anime, i) => {
          const actualIndex = Math.max(0, currentIndex - 2) + i;
          return (
            <button
              key={anime.slug}
              onClick={() => onSelectAnime(anime)}
              className={cn(
                "rounded-full transition-all duration-300",
                actualIndex === currentIndex
                  ? "w-2.5 h-6 bg-white shadow-lg"
                  : "w-2 h-2 bg-white/40 hover:bg-white/70"
              )}
            />
          );
        })}
      </div>

      {/* Counter */}
      <div className="absolute left-4 top-4 z-20">
        <div className="bg-black/50 backdrop-blur-md px-3 py-1.5 rounded-full">
          <span className="text-white text-sm font-medium">
            {currentIndex + 1} / {animes.length}
          </span>
        </div>
      </div>

      {/* Swipe hint */}
      {currentIndex === 0 && !isSwiping && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 z-20 animate-pulse">
          <div className="flex flex-col items-center gap-1 text-white/70">
            <ChevronDown className="w-6 h-6 animate-bounce" />
            <span className="text-xs">Desliza para ver más</span>
          </div>
        </div>
      )}
    </div>
  );
}
