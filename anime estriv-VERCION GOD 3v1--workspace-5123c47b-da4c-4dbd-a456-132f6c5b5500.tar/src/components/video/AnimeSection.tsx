'use client';

import { AnimeCard } from './AnimeCard';
import { cn } from '@/lib/utils';
import { useEffect, useState, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface Anime {
  slug: string;
  title: string;
  poster: string;
  year?: string;
  type?: string;
  score?: number;
}

interface SectionProps {
  title: string;
  icon?: React.ReactNode;
  animes: Anime[];
  onSelectAnime: (anime: Anime) => void;
  showArrows?: boolean;
  emptyMessage?: string;
}

export function AnimeSection({ 
  title, 
  icon, 
  animes, 
  onSelectAnime, 
  showArrows = true,
  emptyMessage = "No hay contenido disponible"
}: SectionProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(false);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollLeft(scrollLeft > 0);
      setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    checkScroll();
    const scrollEl = scrollRef.current;
    if (scrollEl) {
      scrollEl.addEventListener('scroll', checkScroll);
      return () => scrollEl.removeEventListener('scroll', checkScroll);
    }
  }, [animes]);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = scrollRef.current.clientWidth * 0.8;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  if (animes.length === 0) return null;

  return (
    <div className="mb-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          {icon}
          <h2 className="text-xl font-bold text-white">{title}</h2>
          <span className="text-sm text-gray-400">({animes.length})</span>
        </div>
        {showArrows && (
          <div className="flex gap-2">
            <button
              onClick={() => scroll('left')}
              disabled={!canScrollLeft}
              className={cn(
                "p-2 rounded-full transition-all",
                canScrollLeft 
                  ? "bg-white/10 hover:bg-white/20 text-white" 
                  : "bg-white/5 text-gray-600 cursor-not-allowed"
              )}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => scroll('right')}
              disabled={!canScrollRight}
              className={cn(
                "p-2 rounded-full transition-all",
                canScrollRight 
                  ? "bg-white/10 hover:bg-white/20 text-white" 
                  : "bg-white/5 text-gray-600 cursor-not-allowed"
              )}
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      {/* Horizontal Scroll */}
      <div
        ref={scrollRef}
        className="flex gap-4 overflow-x-auto scrollbar-hide pb-2"
        style={{ scrollBehavior: 'smooth' }}
      >
        {animes.map((anime) => (
          <div key={anime.slug} className="flex-shrink-0 w-40 md:w-44 lg:w-48">
            <AnimeCard
              anime={anime}
              onClick={() => onSelectAnime(anime)}
              variant="grid"
            />
          </div>
        ))}
      </div>
    </div>
  );
}

// Vertical Grid Section
interface GridSectionProps {
  title?: string;
  animes: Anime[];
  onSelectAnime: (anime: Anime) => void;
  columns?: number;
}

export function AnimeGridSection({ 
  title, 
  animes, 
  onSelectAnime,
  columns = 6
}: GridSectionProps) {
  const gridCols = {
    2: 'grid-cols-2',
    3: 'grid-cols-2 sm:grid-cols-3',
    4: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4',
    5: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5',
    6: 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6',
  };

  return (
    <div className="mb-8">
      {title && (
        <h2 className="text-xl font-bold text-white mb-4">{title}</h2>
      )}
      <div className={`grid ${gridCols[columns as keyof typeof gridCols] || gridCols[6]} gap-4`}>
        {animes.map((anime) => (
          <AnimeCard
            key={anime.slug}
            anime={anime}
            onClick={() => onSelectAnime(anime)}
            variant="grid"
          />
        ))}
      </div>
      {animes.length === 0 && (
        <div className="text-center py-12 text-gray-400">
          No hay contenido disponible
        </div>
      )}
    </div>
  );
}
