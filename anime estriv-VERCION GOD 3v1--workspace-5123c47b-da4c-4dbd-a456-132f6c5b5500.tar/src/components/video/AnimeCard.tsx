'use client';

import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { Eye, Heart, Play, Star, Tv, Film, Bookmark, Share2, Plus, Check } from 'lucide-react';
import { useState } from 'react';
import { useStore } from '@/lib/store';

interface AnimeCardProps {
  anime: {
    slug: string;
    title: string;
    poster: string;
    year?: string;
    type?: string;
    score?: number;
  };
  onClick: () => void;
  variant?: 'grid' | 'feed' | 'list' | 'continue';
  showActions?: boolean;
  episodeNumber?: number;
  episodeTitle?: string;
}

export function AnimeCard({ 
  anime, 
  onClick, 
  variant = 'grid',
  showActions = true,
  episodeNumber,
  episodeTitle
}: AnimeCardProps) {
  const [showHeart, setShowHeart] = useState(false);
  const [lastTap, setLastTap] = useState(0);
  const [showShareTooltip, setShowShareTooltip] = useState(false);

  const { 
    isLiked, 
    toggleLike, 
    isFavorite, 
    addFavorite, 
    removeFavorite 
  } = useStore();

  const liked = isLiked(anime.slug);
  const favorite = isFavorite(anime.slug);

  const handleDoubleTap = () => {
    const now = Date.now();
    if (now - lastTap < 300) {
      setShowHeart(true);
      toggleLike(anime.slug);
      setTimeout(() => setShowHeart(false), 1000);
    }
    setLastTap(now);
  };

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (favorite) {
      removeFavorite(anime.slug);
    } else {
      addFavorite({
        slug: anime.slug,
        title: anime.title,
        poster: anime.poster,
        type: anime.type,
        score: anime.score
      });
    }
  };

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleLike(anime.slug);
  };

  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const shareData = {
      title: anime.title,
      text: `Mira ${anime.title} en AnimeStream!`,
      url: `${window.location.origin}?anime=${anime.slug}`
    };
    
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(shareData.url);
        setShowShareTooltip(true);
        setTimeout(() => setShowShareTooltip(false), 2000);
      }
    } catch (err) {
      console.log('Share cancelled');
    }
  };

  // Continue watching card
  if (variant === 'continue') {
    return (
      <div
        onClick={onClick}
        className="group cursor-pointer flex gap-4 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-all"
      >
        {/* Thumbnail */}
        <div className="relative w-32 aspect-video rounded-lg overflow-hidden flex-shrink-0">
          {anime.poster ? (
            <img
              src={anime.poster}
              alt={anime.title}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-purple-900 to-gray-900 flex items-center justify-center">
              <Tv className="w-8 h-8 text-purple-400" />
            </div>
          )}
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
            <Play className="w-10 h-10 text-white fill-white" />
          </div>
          <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded">
            EP {episodeNumber}
          </div>
        </div>

        {/* Info */}
        <div className="flex-1 min-w-0 flex flex-col justify-center">
          <h4 className="text-white font-medium line-clamp-1">{anime.title}</h4>
          <p className="text-gray-400 text-sm">Episodio {episodeNumber}</p>
          {episodeTitle && (
            <p className="text-gray-500 text-xs line-clamp-1">{episodeTitle}</p>
          )}
          <div className="mt-2 h-1 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-purple-500 w-1/3" />
          </div>
        </div>
      </div>
    );
  }

  // TikTok-style feed card
  if (variant === 'feed') {
    return (
      <div
        onClick={onClick}
        className="relative w-full h-full cursor-pointer group"
        onDoubleClick={handleDoubleTap}
      >
        {/* Poster Background */}
        <div className="absolute inset-0">
          {anime.poster ? (
            <img
              src={anime.poster}
              alt={anime.title}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-purple-900 to-gray-900 flex items-center justify-center">
              <Tv className="w-20 h-20 text-purple-400" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/30 via-transparent to-transparent" />
        </div>

        {/* Double tap heart animation */}
        {showHeart && (
          <div className="absolute inset-0 flex items-center justify-center z-50 pointer-events-none">
            <Heart className="w-32 h-32 text-red-500 fill-red-500 animate-ping" />
          </div>
        )}

        {/* Type Badge */}
        {anime.type && (
          <div className="absolute top-16 left-3 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs px-3 py-1 rounded-full font-semibold shadow-lg">
            {anime.type}
          </div>
        )}

        {/* Right Side Actions */}
        {showActions && (
          <div className="absolute right-3 bottom-32 flex flex-col items-center gap-5 z-20">
            {/* Like */}
            <button
              onClick={handleLike}
              className="flex flex-col items-center gap-1 group/btn"
            >
              <div className={cn(
                "w-12 h-12 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center transition-all duration-300 group-hover/btn:bg-black/60 group-hover/btn:scale-110",
                liked && "bg-red-500/80"
              )}>
                <Heart className={cn(
                  "w-6 h-6 transition-all",
                  liked ? "text-white fill-white" : "text-white"
                )} />
              </div>
              <span className="text-white text-xs font-semibold drop-shadow-lg">
                {liked ? 'Te gusta' : 'Me gusta'}
              </span>
            </button>

            {/* Favorite */}
            <button
              onClick={handleFavorite}
              className="flex flex-col items-center gap-1 group/btn"
            >
              <div className={cn(
                "w-12 h-12 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center transition-all duration-300 group-hover/btn:bg-black/60 group-hover/btn:scale-110",
                favorite && "bg-purple-500/80"
              )}>
                {favorite ? (
                  <Check className="w-6 h-6 text-white" />
                ) : (
                  <Plus className="w-6 h-6 text-white" />
                )}
              </div>
              <span className="text-white text-xs font-semibold drop-shadow-lg">
                {favorite ? 'Guardado' : 'Guardar'}
              </span>
            </button>

            {/* Share */}
            <button
              onClick={handleShare}
              className="flex flex-col items-center gap-1 group/btn relative"
            >
              <div className="w-12 h-12 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center transition-all duration-300 group-hover/btn:bg-black/60 group-hover/btn:scale-110">
                <Share2 className="w-6 h-6 text-white" />
              </div>
              <span className="text-white text-xs font-semibold drop-shadow-lg">
                Compartir
              </span>
              {showShareTooltip && (
                <div className="absolute -top-8 bg-black px-2 py-1 rounded text-xs text-white whitespace-nowrap">
                  Enlace copiado!
                </div>
              )}
            </button>

            {/* Watch */}
            <button className="flex flex-col items-center gap-1 group/btn" onClick={onClick}>
              <div className="w-12 h-12 rounded-full bg-purple-500 flex items-center justify-center transition-all duration-300 group-hover/btn:bg-purple-400 group-hover/btn:scale-110">
                <Play className="w-6 h-6 text-white fill-white ml-0.5" />
              </div>
              <span className="text-white text-xs font-semibold drop-shadow-lg">Ver</span>
            </button>
          </div>
        )}

        {/* Content Overlay - Bottom */}
        <div className="absolute bottom-20 left-0 right-16 p-4 z-10">
          <h3 className="text-white font-bold text-lg mb-2 line-clamp-2 drop-shadow-lg">
            {anime.title}
          </h3>
          <div className="flex items-center gap-3 flex-wrap">
            {anime.score && anime.score > 0 && (
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                <span className="text-white text-sm">{anime.score.toFixed(1)}</span>
              </div>
            )}
            {anime.year && (
              <span className="text-white/70 text-sm">{anime.year}</span>
            )}
            {anime.type && (
              <Badge className="bg-white/20 text-white text-xs">{anime.type}</Badge>
            )}
          </div>
        </div>

        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
          <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center shadow-2xl">
            <Play className="w-8 h-8 text-white fill-white ml-1" />
          </div>
        </div>
      </div>
    );
  }

  // List variant for sidebar
  if (variant === 'list') {
    return (
      <div
        onClick={onClick}
        className="flex gap-3 p-2 rounded-xl hover:bg-white/10 cursor-pointer transition-all duration-200 group"
      >
        <div className="relative w-16 h-24 flex-shrink-0 rounded-lg overflow-hidden">
          {anime.poster ? (
            <img
              src={anime.poster}
              alt={anime.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              loading="lazy"
            />
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-purple-900 to-gray-900 flex items-center justify-center">
              <Film className="w-6 h-6 text-purple-400" />
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0 py-0.5">
          <h4 className="font-semibold text-sm line-clamp-2 mb-1 group-hover:text-purple-400 transition-colors text-white">
            {anime.title}
          </h4>
          <div className="flex items-center gap-2 text-xs text-gray-400">
            {anime.type && <span>{anime.type}</span>}
            {anime.year && <span>• {anime.year}</span>}
          </div>
        </div>
      </div>
    );
  }

  // Grid variant (default) - YouTube style
  return (
    <div
      onClick={onClick}
      className="group cursor-pointer relative"
    >
      {/* Thumbnail */}
      <div className="relative aspect-[2/3] rounded-xl overflow-hidden mb-3 bg-gradient-to-br from-purple-900 to-gray-900">
        {anime.poster ? (
          <img
            src={anime.poster}
            alt={anime.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Tv className="w-12 h-12 text-purple-400" />
          </div>
        )}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />

        {/* Type Badge */}
        {anime.type && (
          <div className="absolute top-2 left-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs px-2 py-0.5 rounded-full font-semibold shadow-lg">
            {anime.type}
          </div>
        )}

        {/* Score Badge */}
        {anime.score && anime.score > 0 && (
          <div className="absolute top-2 right-2 bg-black/70 backdrop-blur-sm text-white text-xs px-2 py-0.5 rounded-full flex items-center gap-1">
            <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
            {anime.score.toFixed(1)}
          </div>
        )}

        {/* Liked indicator */}
        {liked && (
          <div className="absolute bottom-2 left-2 bg-red-500/80 p-1.5 rounded-full">
            <Heart className="w-3 h-3 text-white fill-white" />
          </div>
        )}

        {/* Favorite indicator */}
        {favorite && (
          <div className="absolute bottom-2 right-2 bg-purple-500/80 p-1.5 rounded-full">
            <Bookmark className="w-3 h-3 text-white fill-white" />
          </div>
        )}

        {/* Play Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <div className="w-14 h-14 rounded-full bg-white/90 flex items-center justify-center shadow-2xl transform group-hover:scale-110 transition-transform">
            <Play className="w-6 h-6 text-purple-600 fill-purple-600 ml-1" />
          </div>
        </div>
      </div>

      {/* Info Section */}
      <div className="space-y-1">
        <h3 className="font-semibold text-sm line-clamp-2 group-hover:text-purple-400 transition-colors text-white">
          {anime.title}
        </h3>
        <div className="flex items-center gap-2 text-xs text-gray-400">
          {anime.year && <span>{anime.year}</span>}
          {anime.type && (
            <>
              <span>•</span>
              <span>{anime.type}</span>
            </>
          )}
        </div>
      </div>

      {/* Hover Actions */}
      {showActions && (
        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col gap-1">
          <button
            onClick={handleLike}
            className={cn(
              "p-1.5 rounded-full backdrop-blur-sm transition-colors",
              liked ? "bg-red-500 text-white" : "bg-black/50 text-white hover:bg-black/70"
            )}
          >
            <Heart className={cn("w-4 h-4", liked && "fill-white")} />
          </button>
          <button
            onClick={handleFavorite}
            className={cn(
              "p-1.5 rounded-full backdrop-blur-sm transition-colors",
              favorite ? "bg-purple-500 text-white" : "bg-black/50 text-white hover:bg-black/70"
            )}
          >
            <Bookmark className={cn("w-4 h-4", favorite && "fill-white")} />
          </button>
        </div>
      )}
    </div>
  );
}
