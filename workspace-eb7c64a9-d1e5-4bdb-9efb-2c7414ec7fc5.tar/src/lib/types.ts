// Types for Anime Streaming Platform

export interface Anime {
  id: string;
  title: string;
  cover: string;
  description: string;
  genre: string[];
  status: 'ongoing' | 'completed' | 'upcoming';
  rating: number;
  year: number;
  createdAt: string;
  updatedAt: string;
}

export interface Episode {
  id: string;
  animeId: string;
  title: string;
  episodeNumber: number;
  videoUrl: string;
  thumbnail: string;
  duration: number; // in seconds
  views: number;
  likes: number;
  createdAt: string;
  updatedAt: string;
}

export interface Comment {
  id: string;
  episodeId: string;
  userId: string;
  userName: string;
  userAvatar: string;
  content: string;
  likes: number;
  replies: Comment[];
  createdAt: string;
  updatedAt: string;
}

export interface Like {
  id: string;
  userId: string;
  targetType: 'episode' | 'comment';
  targetId: string;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  avatar: string;
  likedEpisodes: string[];
  likedComments: string[];
  watchHistory: WatchHistoryItem[];
}

export interface WatchHistoryItem {
  episodeId: string;
  progress: number; // percentage 0-100
  timestamp: string;
}

// API Response Types
export interface ScraperResponse {
  success: boolean;
  data?: {
    animes: Anime[];
    episodes: Episode[];
  };
  error?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

// UI State Types
export type ViewMode = 'mobile' | 'desktop';
export type AppView = 'home' | 'player' | 'studio' | 'anime-detail';

export interface AppState {
  viewMode: ViewMode;
  appView: AppView;
  currentAnime: Anime | null;
  currentEpisode: Episode | null;
  searchQuery: string;
  isSidebarOpen: boolean;
  isStudioMode: boolean;
}

// Scraper Source Types
export interface ScraperAnime {
  title: string;
  url: string;
  cover?: string;
  description?: string;
}

export interface ScraperEpisode {
  title: string;
  url: string;
  animeTitle: string;
  episodeNumber?: number;
  thumbnail?: string;
  videoUrl?: string;
}
