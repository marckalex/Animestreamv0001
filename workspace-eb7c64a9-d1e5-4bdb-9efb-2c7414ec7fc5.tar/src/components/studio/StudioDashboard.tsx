'use client';

import { useState } from 'react';
import { Anime, Episode, Comment } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { cn } from '@/lib/utils';
import {
  Play,
  RefreshCw,
  Edit2,
  Trash2,
  Eye,
  Heart,
  MessageCircle,
  Film,
  Settings,
  Database,
  Download,
  X,
  Check,
  Loader2
} from 'lucide-react';

interface StudioDashboardProps {
  animes: Anime[];
  episodes: Episode[];
  comments: Comment[];
  onScrape: () => Promise<void>;
  onUpdateAnime: (anime: Anime) => void;
  onDeleteAnime: (id: string) => void;
  onUpdateEpisode: (episode: Episode) => void;
  onDeleteEpisode: (id: string) => void;
  onDeleteComment: (id: string) => void;
  onClose: () => void;
  isScraping: boolean;
}

export function StudioDashboard({
  animes,
  episodes,
  comments,
  onScrape,
  onUpdateAnime,
  onDeleteAnime,
  onUpdateEpisode,
  onDeleteEpisode,
  onDeleteComment,
  onClose,
  isScraping
}: StudioDashboardProps) {
  const [editingAnime, setEditingAnime] = useState<Anime | null>(null);
  const [editingEpisode, setEditingEpisode] = useState<Episode | null>(null);
  const [activeTab, setActiveTab] = useState('overview');

  const formatViews = (num: number) => {
    if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
    if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
    return num.toString();
  };

  const totalViews = episodes.reduce((sum, ep) => sum + ep.views, 0);
  const totalLikes = episodes.reduce((sum, ep) => sum + ep.likes, 0);

  return (
    <div className="fixed inset-0 bg-background z-50 overflow-hidden">
      {/* Header */}
      <header className="h-14 border-b border-border flex items-center justify-between px-4 bg-card">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Settings className="w-4 h-4 text-white" />
          </div>
          <h1 className="font-bold text-lg">Panel de Administración</h1>
          <Badge variant="secondary">Studio Mode</Badge>
        </div>
        <div className="flex items-center gap-2">
          <Button
            onClick={onScrape}
            disabled={isScraping}
            className="gap-2"
          >
            {isScraping ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Download className="w-4 h-4" />
            )}
            {isScraping ? 'Scrapeando...' : 'Ejecutar Scraper'}
          </Button>
          <Button variant="ghost" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex h-[calc(100vh-56px)]">
        {/* Sidebar */}
        <div className="w-64 border-r border-border bg-card/50">
          <nav className="p-4 space-y-2">
            <button
              onClick={() => setActiveTab('overview')}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                activeTab === 'overview'
                  ? "bg-primary/10 text-primary"
                  : "hover:bg-secondary"
              )}
            >
              <Database className="w-4 h-4" />
              Resumen
            </button>
            <button
              onClick={() => setActiveTab('animes')}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                activeTab === 'animes'
                  ? "bg-primary/10 text-primary"
                  : "hover:bg-secondary"
              )}
            >
              <Film className="w-4 h-4" />
              Animes ({animes.length})
            </button>
            <button
              onClick={() => setActiveTab('episodes')}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                activeTab === 'episodes'
                  ? "bg-primary/10 text-primary"
                  : "hover:bg-secondary"
              )}
            >
              <Play className="w-4 h-4" />
              Episodios ({episodes.length})
            </button>
            <button
              onClick={() => setActiveTab('comments')}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-colors",
                activeTab === 'comments'
                  ? "bg-primary/10 text-primary"
                  : "hover:bg-secondary"
              )}
            >
              <MessageCircle className="w-4 h-4" />
              Comentarios ({comments.length})
            </button>
          </nav>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-auto p-6">
          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Resumen de la Plataforma</h2>
              
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-muted-foreground">Total Animes</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{animes.length}</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-muted-foreground">Total Episodios</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{episodes.length}</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-muted-foreground">Vistas Totales</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{formatViews(totalViews)}</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm text-muted-foreground">Likes Totales</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold">{formatViews(totalLikes)}</div>
                  </CardContent>
                </Card>
              </div>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Episodios Recientes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {episodes.slice(0, 5).map((ep) => {
                      const anime = animes.find(a => a.id === ep.animeId);
                      return (
                        <div key={ep.id} className="flex items-center gap-4">
                          <img
                            src={ep.thumbnail}
                            alt={ep.title}
                            className="w-16 h-10 object-cover rounded"
                          />
                          <div className="flex-1">
                            <p className="font-medium text-sm">{ep.title}</p>
                            <p className="text-xs text-muted-foreground">{anime?.title}</p>
                          </div>
                          <div className="flex items-center gap-4 text-xs text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Eye className="w-3 h-3" />
                              {formatViews(ep.views)}
                            </span>
                            <span className="flex items-center gap-1">
                              <Heart className="w-3 h-3" />
                              {formatViews(ep.likes)}
                            </span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Animes Tab */}
          {activeTab === 'animes' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Gestión de Animes</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {animes.map((anime) => (
                  <Card key={anime.id} className="overflow-hidden">
                    <div className="relative h-40">
                      <img
                        src={anime.cover}
                        alt={anime.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                      <div className="absolute bottom-2 left-2 right-2">
                        <h3 className="font-semibold text-white truncate">{anime.title}</h3>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant={anime.status === 'ongoing' ? 'default' : 'secondary'}>
                          {anime.status === 'ongoing' ? 'En emisión' : anime.status === 'completed' ? 'Completado' : 'Próximo'}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{anime.rating} ⭐</span>
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                        {anime.description}
                      </p>
                      <div className="flex items-center gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" className="flex-1">
                              <Edit2 className="w-4 h-4 mr-1" />
                              Editar
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Editar Anime</DialogTitle>
                            </DialogHeader>
                            <div className="space-y-4 pt-4">
                              <div>
                                <label className="text-sm font-medium">Título</label>
                                <Input
                                  defaultValue={anime.title}
                                  onChange={(e) => setEditingAnime({ ...anime, title: e.target.value })}
                                />
                              </div>
                              <div>
                                <label className="text-sm font-medium">Descripción</label>
                                <Textarea
                                  defaultValue={anime.description}
                                  onChange={(e) => setEditingAnime({ ...anime, description: e.target.value })}
                                />
                              </div>
                              <Button
                                onClick={() => {
                                  if (editingAnime) {
                                    onUpdateAnime(editingAnime);
                                    setEditingAnime(null);
                                  }
                                }}
                              >
                                Guardar Cambios
                              </Button>
                            </div>
                          </DialogContent>
                        </Dialog>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="destructive" size="sm">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>¿Eliminar anime?</AlertDialogTitle>
                              <AlertDialogDescription>
                                Esta acción eliminará "{anime.title}" y todos sus episodios. No se puede deshacer.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancelar</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => onDeleteAnime(anime.id)}
                                className="bg-destructive text-destructive-foreground"
                              >
                                Eliminar
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Episodes Tab */}
          {activeTab === 'episodes' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Gestión de Episodios</h2>
              
              <div className="border rounded-lg">
                <ScrollArea className="h-[calc(100vh-220px)]">
                  <table className="w-full">
                    <thead className="bg-muted/50 sticky top-0">
                      <tr>
                        <th className="text-left p-3 text-sm font-medium">Thumbnail</th>
                        <th className="text-left p-3 text-sm font-medium">Título</th>
                        <th className="text-left p-3 text-sm font-medium">Anime</th>
                        <th className="text-left p-3 text-sm font-medium">Vistas</th>
                        <th className="text-left p-3 text-sm font-medium">Likes</th>
                        <th className="text-left p-3 text-sm font-medium">Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {episodes.map((ep) => {
                        const anime = animes.find(a => a.id === ep.animeId);
                        return (
                          <tr key={ep.id} className="border-t hover:bg-muted/30">
                            <td className="p-3">
                              <img
                                src={ep.thumbnail}
                                alt={ep.title}
                                className="w-24 h-14 object-cover rounded"
                              />
                            </td>
                            <td className="p-3">
                              <p className="font-medium text-sm">{ep.title}</p>
                              <p className="text-xs text-muted-foreground">EP {ep.episodeNumber}</p>
                            </td>
                            <td className="p-3 text-sm">{anime?.title}</td>
                            <td className="p-3 text-sm">{formatViews(ep.views)}</td>
                            <td className="p-3 text-sm">{formatViews(ep.likes)}</td>
                            <td className="p-3">
                              <div className="flex items-center gap-2">
                                <Button variant="ghost" size="sm">
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                                <AlertDialog>
                                  <AlertDialogTrigger asChild>
                                    <Button variant="ghost" size="sm">
                                      <Trash2 className="w-4 h-4 text-destructive" />
                                    </Button>
                                  </AlertDialogTrigger>
                                  <AlertDialogContent>
                                    <AlertDialogHeader>
                                      <AlertDialogTitle>¿Eliminar episodio?</AlertDialogTitle>
                                      <AlertDialogDescription>
                                        Esta acción eliminará "{ep.title}". No se puede deshacer.
                                      </AlertDialogDescription>
                                    </AlertDialogHeader>
                                    <AlertDialogFooter>
                                      <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                      <AlertDialogAction
                                        onClick={() => onDeleteEpisode(ep.id)}
                                        className="bg-destructive text-destructive-foreground"
                                      >
                                        Eliminar
                                      </AlertDialogAction>
                                    </AlertDialogFooter>
                                  </AlertDialogContent>
                                </AlertDialog>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </ScrollArea>
              </div>
            </div>
          )}

          {/* Comments Tab */}
          {activeTab === 'comments' && (
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Moderación de Comentarios</h2>
              
              <div className="space-y-4">
                {comments.map((comment) => {
                  const episode = episodes.find(e => e.id === comment.episodeId);
                  const anime = animes.find(a => a.id === episode?.animeId);
                  return (
                    <Card key={comment.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-4">
                          <img
                            src={comment.userAvatar}
                            alt={comment.userName}
                            className="w-10 h-10 rounded-full"
                          />
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <div>
                                <span className="font-medium">{comment.userName}</span>
                                <span className="text-xs text-muted-foreground ml-2">
                                  en {episode?.title} ({anime?.title})
                                </span>
                              </div>
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button variant="ghost" size="sm">
                                    <Trash2 className="w-4 h-4 text-destructive" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>¿Eliminar comentario?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Esta acción no se puede deshacer.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>Cancelar</AlertDialogCancel>
                                    <AlertDialogAction
                                      onClick={() => onDeleteComment(comment.id)}
                                      className="bg-destructive text-destructive-foreground"
                                    >
                                      Eliminar
                                    </AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                            <p className="text-sm mt-1">{comment.content}</p>
                            <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                              <span>❤️ {comment.likes} likes</span>
                              <span>{new Date(comment.createdAt).toLocaleDateString()}</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
