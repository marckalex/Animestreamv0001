'use client';

import { useState } from 'react';
import { Anime } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { cn } from '@/lib/utils';
import {
  Search,
  Menu,
  Home,
  TrendingUp,
  Clock,
  ThumbsUp,
  Settings,
  Film,
  X
} from 'lucide-react';

interface SidebarProps {
  animes: Anime[];
  selectedAnime: Anime | null;
  onSelectAnime: (anime: Anime | null) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenStudio: () => void;
  isOpen: boolean;
  onToggle: () => void;
}

function SidebarContentInner({
  animes,
  selectedAnime,
  onSelectAnime,
  searchQuery,
  onSearchChange,
  onOpenStudio,
  activeTab,
  setActiveTab
}: {
  animes: Anime[];
  selectedAnime: Anime | null;
  onSelectAnime: (anime: Anime | null) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  onOpenStudio: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}) {
  const filteredAnimes = animes.filter(anime =>
    anime.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const menuItems = [
    { id: 'home', icon: Home, label: 'Inicio' },
    { id: 'trending', icon: TrendingUp, label: 'Tendencias' },
    { id: 'recent', icon: Clock, label: 'Recientes' },
    { id: 'liked', icon: ThumbsUp, label: 'Favoritos' },
  ];

  return (
    <div className="flex flex-col h-full bg-background">
      {/* Logo */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
            <Film className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-lg font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              AnimeStream
            </h1>
            <p className="text-xs text-muted-foreground">Tu plataforma de anime</p>
          </div>
        </div>
      </div>

      {/* Search */}
      <div className="p-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Buscar anime..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pl-9 bg-secondary/50 border-0 focus-visible:ring-1"
          />
          {searchQuery && (
            <button
              onClick={() => onSearchChange('')}
              className="absolute right-3 top-1/2 -translate-y-1/2"
            >
              <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
            </button>
          )}
        </div>
      </div>

      {/* Menu Items */}
      <div className="px-3 py-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => {
              setActiveTab(item.id);
              onSelectAnime(null);
            }}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all",
              activeTab === item.id
                ? "bg-primary/10 text-primary"
                : "hover:bg-secondary text-foreground/80"
            )}
          >
            <item.icon className="w-5 h-5" />
            {item.label}
          </button>
        ))}
      </div>

      {/* Anime List */}
      <div className="flex-1 overflow-hidden">
        <div className="px-3 py-2">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3 mb-2">
            Animes
          </h3>
        </div>
        <ScrollArea className="flex-1 h-[calc(100vh-340px)]">
          <div className="px-3 space-y-1">
            {filteredAnimes.map((anime) => (
              <button
                key={anime.id}
                onClick={() => onSelectAnime(anime)}
                className={cn(
                  "w-full flex items-center gap-3 p-2 rounded-lg transition-all",
                  selectedAnime?.id === anime.id
                    ? "bg-primary/10 border border-primary/20"
                    : "hover:bg-secondary"
                )}
              >
                <img
                  src={anime.cover}
                  alt={anime.title}
                  className="w-10 h-14 object-cover rounded-md"
                  loading="lazy"
                />
                <div className="flex-1 text-left overflow-hidden">
                  <p className="text-sm font-medium truncate">{anime.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {anime.status === 'ongoing' ? 'En emisión' : anime.status === 'completed' ? 'Completado' : 'Próximamente'}
                  </p>
                </div>
              </button>
            ))}
            
            {filteredAnimes.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <Film className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No se encontraron animes</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Studio Button */}
      <div className="p-3 border-t border-border">
        <Button
          onClick={onOpenStudio}
          variant="outline"
          className="w-full justify-start gap-2"
        >
          <Settings className="w-4 h-4" />
          Panel de Administración
        </Button>
      </div>
    </div>
  );
}

export function Sidebar({
  animes,
  selectedAnime,
  onSelectAnime,
  searchQuery,
  onSearchChange,
  onOpenStudio,
  isOpen,
  onToggle
}: SidebarProps) {
  const [activeTab, setActiveTab] = useState('home');

  return (
    <>
      {/* Desktop Sidebar */}
      <aside
        className={cn(
          "hidden md:flex flex-col fixed left-0 top-0 h-full bg-background border-r border-border transition-all duration-300 z-40",
          isOpen ? "w-64" : "w-0 overflow-hidden"
        )}
      >
        <SidebarContentInner
          animes={animes}
          selectedAnime={selectedAnime}
          onSelectAnime={onSelectAnime}
          searchQuery={searchQuery}
          onSearchChange={onSearchChange}
          onOpenStudio={onOpenStudio}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />
      </aside>

      {/* Mobile Sheet */}
      <Sheet>
        <SheetTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden fixed top-3 left-3 z-50"
          >
            <Menu className="w-5 h-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0 w-72">
          <SidebarContentInner
            animes={animes}
            selectedAnime={selectedAnime}
            onSelectAnime={onSelectAnime}
            searchQuery={searchQuery}
            onSearchChange={onSearchChange}
            onOpenStudio={onOpenStudio}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
          />
        </SheetContent>
      </Sheet>
    </>
  );
}
