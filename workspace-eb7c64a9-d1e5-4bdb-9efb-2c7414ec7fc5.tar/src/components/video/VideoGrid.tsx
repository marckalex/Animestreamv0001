'use client';

import { Episode, Anime } from '@/lib/types';
import { VideoCard } from './VideoCard';

interface VideoGridProps {
  episodes: Episode[];
  animes: Anime[];
  selectedAnime: Anime | null;
  onSelectEpisode: (episode: Episode) => void;
  hasMore: boolean;
  onLoadMore: () => void;
}

export function VideoGrid({
  episodes,
  animes,
  selectedAnime,
  onSelectEpisode,
  hasMore,
  onLoadMore
}: VideoGridProps) {
  // Filter episodes by selected anime
  const displayEpisodes = selectedAnime
    ? episodes.filter(e => e.animeId === selectedAnime.id)
    : episodes;

  return (
    <div className="p-4 md:p-6">
      {/* Section Header */}
      {selectedAnime && (
        <div className="mb-6">
          <h2 className="text-2xl font-bold mb-2">{selectedAnime.title}</h2>
          <p className="text-muted-foreground">{selectedAnime.description}</p>
          <div className="flex items-center gap-2 mt-3">
            {selectedAnime.genre.map((g) => (
              <span
                key={g}
                className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full"
              >
                {g}
              </span>
            ))}
            <span className="text-xs text-muted-foreground">
              • {selectedAnime.rating} ⭐
            </span>
            <span className="text-xs text-muted-foreground">
              • {selectedAnime.year}
            </span>
          </div>
        </div>
      )}

      {!selectedAnime && (
        <div className="mb-6">
          <h2 className="text-xl font-bold">
            {selectedAnime ? 'Episodios' : 'Últimos Episodios'}
          </h2>
          <p className="text-muted-foreground text-sm">
            {displayEpisodes.length} episodios disponibles
          </p>
        </div>
      )}

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-4">
        {displayEpisodes.map((episode) => {
          const anime = animes.find(a => a.id === episode.animeId);
          return (
            <VideoCard
              key={episode.id}
              episode={episode}
              anime={anime}
              onClick={() => onSelectEpisode(episode)}
              variant="grid"
            />
          );
        })}
      </div>

      {/* Load More */}
      {hasMore && (
        <div className="flex justify-center mt-8">
          <button
            onClick={onLoadMore}
            className="px-6 py-3 bg-secondary hover:bg-secondary/80 rounded-lg transition-colors"
          >
            Cargar más episodios
          </button>
        </div>
      )}

      {/* Empty State */}
      {displayEpisodes.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16">
          <div className="w-16 h-16 rounded-full bg-secondary flex items-center justify-center mb-4">
            <span className="text-3xl">📺</span>
          </div>
          <h3 className="text-lg font-semibold mb-2">No hay episodios</h3>
          <p className="text-muted-foreground text-center max-w-md">
            {selectedAnime
              ? `No hay episodios disponibles para ${selectedAnime.title}`
              : 'No hay episodios disponibles. Intenta ejecutar el scraper desde el panel de administración.'}
          </p>
        </div>
      )}
    </div>
  );
}
