'use client';

import { useState, useRef, useEffect } from 'react';
import { Episode, Anime, Comment } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Maximize,
  Minimize,
  ThumbsUp,
  ThumbsDown,
  Share2,
  Download,
  Heart,
  MessageCircle,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';

interface VideoPlayerProps {
  episode: Episode;
  anime?: Anime;
  comments: Comment[];
  relatedEpisodes: Episode[];
  isLiked: boolean;
  onLike: () => void;
  onComment: (content: string) => void;
  onSelectEpisode: (episode: Episode) => void;
  isMobile?: boolean;
  onNext?: () => void;
  onPrev?: () => void;
}

export function VideoPlayer({
  episode,
  anime,
  comments,
  relatedEpisodes,
  isLiked,
  onLike,
  onComment,
  onSelectEpisode,
  isMobile = false,
  onNext,
  onPrev
}: VideoPlayerProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showComments, setShowComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const videoRef = useRef<HTMLDivElement>(null);

  const formatViews = (views: number) => {
    if (views >= 1000000) {
      return `${(views / 1000000).toFixed(1)}M`;
    }
    if (views >= 1000) {
      return `${(views / 1000).toFixed(1)}K`;
    }
    return views.toString();
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleMute = () => {
    setIsMuted(!isMuted);
  };

  const handleFullscreen = () => {
    if (!document.fullscreenElement) {
      videoRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const handleSubmitComment = () => {
    if (newComment.trim()) {
      onComment(newComment);
      setNewComment('');
    }
  };

  // Mobile TikTok-style player
  if (isMobile) {
    return (
      <div className="relative w-full h-full bg-black" ref={videoRef}>
        {/* Video Placeholder with Thumbnail */}
        <div className="absolute inset-0 flex items-center justify-center">
          <img
            src={episode.thumbnail}
            alt={episode.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/20" />
        </div>

        {/* Play Button */}
        <button
          onClick={handlePlayPause}
          className="absolute inset-0 flex items-center justify-center"
        >
          {!isPlaying && (
            <div className="w-20 h-20 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
              <Play className="w-10 h-10 text-white fill-white ml-1" />
            </div>
          )}
        </button>

        {/* Progress Bar */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/20">
          <div
            className="h-full bg-primary transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Right Side Actions */}
        <div className="absolute right-4 bottom-32 flex flex-col items-center gap-6">
          {/* Like */}
          <button
            onClick={onLike}
            className="flex flex-col items-center gap-1"
          >
            <div className={cn(
              "w-12 h-12 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center transition-transform active:scale-90",
              isLiked && "bg-red-500/60"
            )}>
              <Heart className={cn(
                "w-6 h-6 text-white",
                isLiked && "fill-white"
              )} />
            </div>
            <span className="text-white text-xs">{formatViews(episode.likes)}</span>
          </button>

          {/* Comments */}
          <button
            onClick={() => setShowComments(true)}
            className="flex flex-col items-center gap-1"
          >
            <div className="w-12 h-12 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <span className="text-white text-xs">{comments.length}</span>
          </button>

          {/* Share */}
          <button className="flex flex-col items-center gap-1">
            <div className="w-12 h-12 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center">
              <Share2 className="w-6 h-6 text-white" />
            </div>
            <span className="text-white text-xs">Compartir</span>
          </button>
        </div>

        {/* Bottom Info */}
        <div className="absolute bottom-4 left-4 right-20">
          <div className="mb-2">
            <span className="bg-primary/80 text-white text-xs px-2 py-0.5 rounded">
              {anime?.title}
            </span>
          </div>
          <h2 className="text-white font-semibold text-lg mb-1">
            {episode.title}
          </h2>
          <p className="text-white/70 text-sm">
            {formatViews(episode.views)} vistas
          </p>
        </div>

        {/* Navigation Arrows */}
        {onPrev && (
          <button
            onClick={onPrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
        )}
        {onNext && (
          <button
            onClick={onNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center"
          >
            <ChevronRight className="w-6 h-6 text-white" />
          </button>
        )}

        {/* Comments Sheet */}
        {showComments && (
          <div className="fixed inset-0 z-50 bg-black/50" onClick={() => setShowComments(false)}>
            <div
              className="absolute bottom-0 left-0 right-0 bg-background rounded-t-2xl max-h-[70vh] overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-4 border-b border-border">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold">Comentarios</h3>
                  <button onClick={() => setShowComments(false)}>
                    ✕
                  </button>
                </div>
              </div>
              <ScrollArea className="h-[40vh]">
                <div className="p-4 space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex gap-3">
                      <img
                        src={comment.userAvatar}
                        alt={comment.userName}
                        className="w-8 h-8 rounded-full"
                      />
                      <div>
                        <p className="text-sm font-medium">{comment.userName}</p>
                        <p className="text-sm text-muted-foreground">{comment.content}</p>
                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                          <span>❤️ {comment.likes}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
              <div className="p-4 border-t border-border">
                <div className="flex gap-2">
                  <Textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Añadir comentario..."
                    className="min-h-[40px] resize-none"
                  />
                  <Button onClick={handleSubmitComment}>Enviar</Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Desktop YouTube-style player
  return (
    <div className="flex flex-col lg:flex-row gap-6">
      {/* Main Player */}
      <div className="flex-1">
        <div
          className="relative aspect-video bg-black rounded-xl overflow-hidden"
          ref={videoRef}
        >
          {/* Video Placeholder */}
          <div className="absolute inset-0 flex items-center justify-center">
            <img
              src={episode.thumbnail}
              alt={episode.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/30" />
          </div>

          {/* Controls Overlay */}
          <div className="absolute inset-0 flex flex-col justify-end opacity-0 hover:opacity-100 transition-opacity">
            {/* Progress Bar */}
            <div className="px-4">
              <div className="h-1 bg-white/30 rounded-full cursor-pointer">
                <div
                  className="h-full bg-red-500 rounded-full"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            {/* Control Buttons */}
            <div className="flex items-center justify-between p-4 bg-gradient-to-t from-black/80 to-transparent">
              <div className="flex items-center gap-4">
                <button onClick={handlePlayPause}>
                  {isPlaying ? (
                    <Pause className="w-6 h-6 text-white" />
                  ) : (
                    <Play className="w-6 h-6 text-white fill-white" />
                  )}
                </button>
                <button onClick={handleMute}>
                  {isMuted ? (
                    <VolumeX className="w-6 h-6 text-white" />
                  ) : (
                    <Volume2 className="w-6 h-6 text-white" />
                  )}
                </button>
              </div>
              <button onClick={handleFullscreen}>
                {isFullscreen ? (
                  <Minimize className="w-6 h-6 text-white" />
                ) : (
                  <Maximize className="w-6 h-6 text-white" />
                )}
              </button>
            </div>
          </div>

          {/* Center Play Button */}
          <button
            onClick={handlePlayPause}
            className="absolute inset-0 flex items-center justify-center"
          >
            {!isPlaying && (
              <div className="w-16 h-16 rounded-full bg-red-600 flex items-center justify-center shadow-lg">
                <Play className="w-8 h-8 text-white fill-white ml-1" />
              </div>
            )}
          </button>
        </div>

        {/* Video Info */}
        <div className="mt-4">
          <h1 className="text-xl font-bold mb-2">{episode.title}</h1>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4 text-muted-foreground">
              <span>{formatViews(episode.views)} vistas</span>
              <span>hace 2 días</span>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={onLike}
                className={cn(isLiked && "bg-red-500/10 text-red-500")}
              >
                <ThumbsUp className={cn("w-4 h-4 mr-2", isLiked && "fill-current")} />
                {formatViews(episode.likes)}
              </Button>
              <Button variant="secondary" size="sm">
                <ThumbsDown className="w-4 h-4" />
              </Button>
              <Button variant="secondary" size="sm">
                <Share2 className="w-4 h-4 mr-2" />
                Compartir
              </Button>
              <Button variant="secondary" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Descargar
              </Button>
            </div>
          </div>

          {/* Anime Info */}
          {anime && (
            <div className="mt-4 p-4 bg-secondary/50 rounded-xl">
              <div className="flex items-center gap-4">
                <img
                  src={anime.cover}
                  alt={anime.title}
                  className="w-16 h-20 object-cover rounded-lg"
                />
                <div>
                  <h3 className="font-semibold">{anime.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {anime.description}
                  </p>
                  <div className="flex items-center gap-2 mt-2">
                    {anime.genre.map((g) => (
                      <span key={g} className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded">
                        {g}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Comments Section */}
          <div className="mt-6">
            <h3 className="font-semibold mb-4">{comments.length} Comentarios</h3>
            
            {/* Add Comment */}
            <div className="flex gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500" />
              <div className="flex-1">
                <Textarea
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Añadir un comentario..."
                  className="min-h-[80px] resize-none mb-2"
                />
                <div className="flex justify-end gap-2">
                  <Button variant="ghost" size="sm" onClick={() => setNewComment('')}>
                    Cancelar
                  </Button>
                  <Button size="sm" onClick={handleSubmitComment}>
                    Comentar
                  </Button>
                </div>
              </div>
            </div>

            {/* Comments List */}
            <div className="space-y-4">
              {comments.map((comment) => (
                <div key={comment.id} className="flex gap-3">
                  <img
                    src={comment.userAvatar}
                    alt={comment.userName}
                    className="w-10 h-10 rounded-full"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-sm">{comment.userName}</span>
                      <span className="text-xs text-muted-foreground">
                        hace 1 día
                      </span>
                    </div>
                    <p className="text-sm mt-1">{comment.content}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <button className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
                        <ThumbsUp className="w-3 h-3" />
                        {comment.likes}
                      </button>
                      <button className="text-xs text-muted-foreground hover:text-foreground">
                        Responder
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Related Videos Sidebar */}
      <div className="w-full lg:w-80 space-y-2">
        <h3 className="font-semibold mb-4">Videos Relacionados</h3>
        {relatedEpisodes.slice(0, 8).map((ep) => (
          <div
            key={ep.id}
            onClick={() => onSelectEpisode(ep)}
            className="flex gap-2 p-2 rounded-lg hover:bg-secondary cursor-pointer transition-colors"
          >
            <div className="relative w-40 aspect-video rounded-lg overflow-hidden flex-shrink-0">
              <img
                src={ep.thumbnail}
                alt={ep.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-medium line-clamp-2">{ep.title}</h4>
              <p className="text-xs text-muted-foreground mt-1">{anime?.title}</p>
              <p className="text-xs text-muted-foreground">{formatViews(ep.views)} vistas</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
