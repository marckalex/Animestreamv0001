'use client';

import { Episode, Anime } from '@/lib/types';
import { cn } from '@/lib/utils';
import { Eye, Heart, Clock } from 'lucide-react';

interface VideoCardProps {
  episode: Episode;
  anime?: Anime;
  onClick: () => void;
  variant?: 'grid' | 'list' | 'feed';
}

export function VideoCard({ episode, anime, onClick, variant = 'grid' }: VideoCardProps) {
  const formatViews = (views: number) => {
    if (views >= 1000000) {
      return `${(views / 1000000).toFixed(1)}M`;
    }
    if (views >= 1000) {
      return `${(views / 1000).toFixed(1)}K`;
    }
    return views.toString();
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (variant === 'feed') {
    // TikTok-style vertical feed card
    return (
      <div
        onClick={onClick}
        className="relative w-full h-full cursor-pointer group"
      >
        {/* Thumbnail Background */}
        <div className="absolute inset-0">
          <img
            src={episode.thumbnail}
            alt={episode.title}
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        </div>

        {/* Content Overlay */}
        <div className="absolute bottom-0 left-0 right-0 p-4 pb-20">
          <div className="flex items-end justify-between">
            <div className="flex-1 mr-16">
              <h3 className="text-white font-semibold text-lg mb-1 line-clamp-2">
                {anime?.title}
              </h3>
              <p className="text-white/90 text-sm mb-2">
                {episode.title}
              </p>
              <div className="flex items-center gap-4 text-white/70 text-sm">
                <span className="flex items-center gap-1">
                  <Eye className="w-4 h-4" />
                  {formatViews(episode.views)}
                </span>
                <span className="flex items-center gap-1">
                  <Heart className="w-4 h-4" />
                  {formatViews(episode.likes)}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Duration Badge */}
        <div className="absolute top-4 right-4 bg-black/70 text-white text-xs px-2 py-1 rounded">
          {formatDuration(episode.duration)}
        </div>

        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
            <div className="w-0 h-0 border-t-8 border-b-8 border-l-12 border-transparent border-l-white ml-1" />
          </div>
        </div>
      </div>
    );
  }

  if (variant === 'list') {
    // List-style card for recommendations
    return (
      <div
        onClick={onClick}
        className="flex gap-3 p-2 rounded-lg hover:bg-secondary/50 cursor-pointer transition-colors"
      >
        <div className="relative w-40 h-24 flex-shrink-0 rounded-lg overflow-hidden">
          <img
            src={episode.thumbnail}
            alt={episode.title}
            className="w-full h-full object-cover"
            loading="lazy"
          />
          <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded">
            {formatDuration(episode.duration)}
          </div>
        </div>
        <div className="flex-1 min-w-0">
          <h4 className="font-medium text-sm line-clamp-2 mb-1">
            {episode.title}
          </h4>
          <p className="text-xs text-muted-foreground mb-1">
            {anime?.title}
          </p>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Eye className="w-3 h-3" />
              {formatViews(episode.views)}
            </span>
          </div>
        </div>
      </div>
    );
  }

  // Grid-style card (default)
  return (
    <div
      onClick={onClick}
      className="group cursor-pointer"
    >
      <div className="relative aspect-video rounded-xl overflow-hidden mb-2">
        <img
          src={episode.thumbnail}
          alt={episode.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
        
        {/* Duration Badge */}
        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-0.5 rounded">
          {formatDuration(episode.duration)}
        </div>

        {/* Episode Number Badge */}
        <div className="absolute top-2 left-2 bg-primary text-white text-xs px-2 py-0.5 rounded">
          EP {episode.episodeNumber}
        </div>

        {/* Play Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <div className="w-12 h-12 rounded-full bg-primary/90 flex items-center justify-center">
            <div className="w-0 h-0 border-t-6 border-b-6 border-l-8 border-transparent border-l-white ml-1" />
          </div>
        </div>
      </div>

      <div className="space-y-1">
        <h3 className="font-medium text-sm line-clamp-2 group-hover:text-primary transition-colors">
          {episode.title}
        </h3>
        {anime && (
          <p className="text-xs text-muted-foreground">
            {anime.title}
          </p>
        )}
        <div className="flex items-center gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1">
            <Eye className="w-3 h-3" />
            {formatViews(episode.views)} vistas
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            hace 2 días
          </span>
        </div>
      </div>
    </div>
  );
}
