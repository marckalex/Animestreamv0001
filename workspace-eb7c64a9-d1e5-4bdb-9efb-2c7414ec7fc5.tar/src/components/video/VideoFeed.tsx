'use client';

import { useRef, useState, useEffect, useMemo, useCallback } from 'react';
import { Episode, Anime } from '@/lib/types';
import { VideoCard } from './VideoCard';

interface VideoFeedProps {
  episodes: Episode[];
  animes: Anime[];
  currentEpisode: Episode | null;
  onSelectEpisode: (episode: Episode) => void;
  onEndReached: () => void;
}

export function VideoFeed({
  episodes,
  animes,
  currentEpisode,
  onSelectEpisode,
  onEndReached
}: VideoFeedProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const touchStartY = useRef(0);
  const [isSwiping, setIsSwiping] = useState(false);
  const [swipeOffset, setSwipeOffset] = useState(0);

  // Calculate current index from currentEpisode
  const currentIndex = useMemo(() => {
    if (!currentEpisode) return 0;
    const index = episodes.findIndex(e => e.id === currentEpisode.id);
    return index !== -1 ? index : 0;
  }, [currentEpisode, episodes]);

  // Handle touch events for swipe
  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
    setIsSwiping(true);
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!isSwiping) return;
    const diff = touchStartY.current - e.touches[0].clientY;
    setSwipeOffset(diff);
  }, [isSwiping]);

  const goToNext = useCallback(() => {
    if (currentIndex < episodes.length - 1) {
      const nextEpisode = episodes[currentIndex + 1];
      onSelectEpisode(nextEpisode);
      
      // Load more when near end
      if (currentIndex >= episodes.length - 3) {
        onEndReached();
      }
    }
  }, [currentIndex, episodes, onSelectEpisode, onEndReached]);

  const goToPrev = useCallback(() => {
    if (currentIndex > 0) {
      const prevEpisode = episodes[currentIndex - 1];
      onSelectEpisode(prevEpisode);
    }
  }, [currentIndex, episodes, onSelectEpisode]);

  const handleTouchEnd = useCallback(() => {
    setIsSwiping(false);
    
    // Threshold for swipe (100px)
    if (swipeOffset > 100 && currentIndex < episodes.length - 1) {
      // Swipe up - next video
      goToNext();
    } else if (swipeOffset < -100 && currentIndex > 0) {
      // Swipe down - previous video
      goToPrev();
    }
    
    setSwipeOffset(0);
  }, [swipeOffset, currentIndex, episodes.length, goToNext, goToPrev]);

  // Handle wheel for desktop
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let wheelTimeout: ReturnType<typeof setTimeout>;
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      
      clearTimeout(wheelTimeout);
      wheelTimeout = setTimeout(() => {
        if (e.deltaY > 50) {
          goToNext();
        } else if (e.deltaY < -50) {
          goToPrev();
        }
      }, 50);
    };

    container.addEventListener('wheel', handleWheel, { passive: false });
    return () => {
      container.removeEventListener('wheel', handleWheel);
      clearTimeout(wheelTimeout);
    };
  }, [goToNext, goToPrev]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp' || e.key === 'k') {
        goToPrev();
      } else if (e.key === 'ArrowDown' || e.key === 'j') {
        goToNext();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [goToNext, goToPrev]);

  const currentAnime = currentEpisode
    ? animes.find(a => a.id === currentEpisode.animeId)
    : null;

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 bg-black overflow-hidden touch-none"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Video Container with swipe animation */}
      <div
        className="absolute inset-0 transition-transform duration-300 ease-out"
        style={{
          transform: `translateY(${-swipeOffset}px)`,
        }}
      >
        {/* Previous Video Preview */}
        {currentIndex > 0 && (
          <div className="absolute inset-0 -translate-y-full">
            <VideoCard
              episode={episodes[currentIndex - 1]}
              anime={animes.find(a => a.id === episodes[currentIndex - 1].animeId)}
              onClick={() => {}}
              variant="feed"
            />
          </div>
        )}

        {/* Current Video */}
        {currentEpisode && (
          <div className="absolute inset-0">
            <VideoCard
              episode={currentEpisode}
              anime={currentAnime}
              onClick={() => {}}
              variant="feed"
            />
          </div>
        )}

        {/* Next Video Preview */}
        {currentIndex < episodes.length - 1 && (
          <div className="absolute inset-0 translate-y-full">
            <VideoCard
              episode={episodes[currentIndex + 1]}
              anime={animes.find(a => a.id === episodes[currentIndex + 1].animeId)}
              onClick={() => {}}
              variant="feed"
            />
          </div>
        )}
      </div>

      {/* Swipe Indicator */}
      {isSwiping && (
        <div className="absolute left-1/2 top-4 -translate-x-1/2 bg-black/50 backdrop-blur-sm text-white text-xs px-3 py-1.5 rounded-full">
          {swipeOffset > 0 ? 'Siguiente ↓' : 'Anterior ↑'}
        </div>
      )}

      {/* Navigation Dots */}
      <div className="absolute right-2 top-1/2 -translate-y-1/2 flex flex-col gap-2 z-10">
        {episodes.slice(Math.max(0, currentIndex - 3), currentIndex + 4).map((ep, i) => {
          const actualIndex = Math.max(0, currentIndex - 3) + i;
          return (
            <button
              key={ep.id}
              onClick={() => onSelectEpisode(ep)}
              className={`w-2 h-2 rounded-full transition-all ${
                actualIndex === currentIndex
                  ? 'bg-white scale-125'
                  : 'bg-white/50 hover:bg-white/70'
              }`}
            />
          );
        })}
      </div>

      {/* Loading Indicator */}
      {currentIndex >= episodes.length - 2 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
          <div className="flex items-center gap-2 bg-black/50 backdrop-blur-sm text-white text-xs px-3 py-1.5 rounded-full">
            <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            Cargando más...
          </div>
        </div>
      )}
    </div>
  );
}
