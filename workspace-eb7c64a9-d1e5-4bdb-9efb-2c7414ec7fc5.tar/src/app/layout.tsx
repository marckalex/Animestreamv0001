import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "AnimeStream - Plataforma de Anime Híbrida",
  description: "Plataforma de streaming de anime con interfaz TikTok para móvil y YouTube para PC. Scraping en vivo desde animeav1.com",
  keywords: ["anime", "streaming", "TikTok", "YouTube", "animeav1", "español"],
  authors: [{ name: "AnimeStream Team" }],
  icons: {
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎬</text></svg>",
  },
  openGraph: {
    title: "AnimeStream - Tu Plataforma de Anime",
    description: "Disfruta del mejor anime con interfaz moderna estilo TikTok y YouTube",
    url: "https://animestream.app",
    siteName: "AnimeStream",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "AnimeStream",
    description: "Plataforma de streaming de anime",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" className="dark" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
