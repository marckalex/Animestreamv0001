import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

const dataDir = path.join(process.cwd(), 'public', 'data');

function readJsonFile(filename: string) {
  try {
    const filePath = path.join(dataDir, filename);
    const data = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

export async function GET() {
  try {
    const animes = readJsonFile('animes.json');
    const episodes = readJsonFile('episodes.json');
    const comments = readJsonFile('comments.json');
    const likes = readJsonFile('likes.json');

    return NextResponse.json({
      success: true,
      data: {
        animes,
        episodes,
        comments,
        likes
      }
    });
  } catch (error) {
    return NextResponse.json({
      success: false,
      error: 'Error reading data files'
    }, { status: 500 });
  }
}
