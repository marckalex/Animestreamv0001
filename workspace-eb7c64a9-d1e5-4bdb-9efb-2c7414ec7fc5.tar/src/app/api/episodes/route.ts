import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { Episode } from '@/lib/types';

const dataDir = path.join(process.cwd(), 'public', 'data');
const episodesFile = path.join(dataDir, 'episodes.json');

function readEpisodes(): Episode[] {
  try {
    const data = fs.readFileSync(episodesFile, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

function writeEpisodes(episodes: Episode[]) {
  fs.writeFileSync(episodesFile, JSON.stringify(episodes, null, 2));
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const animeId = searchParams.get('animeId');
    const id = searchParams.get('id');
    
    let episodes = readEpisodes();
    
    if (id) {
      const episode = episodes.find(e => e.id === id);
      return NextResponse.json({ success: true, data: episode || null });
    }
    
    if (animeId) {
      episodes = episodes.filter(e => e.animeId === animeId);
    }
    
    return NextResponse.json({ success: true, data: episodes });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error reading episodes' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const episodes = readEpisodes();
    
    const newEpisode: Episode = {
      id: `e${Date.now()}`,
      animeId: body.animeId,
      title: body.title,
      episodeNumber: body.episodeNumber || episodes.filter(e => e.animeId === body.animeId).length + 1,
      videoUrl: body.videoUrl || '',
      thumbnail: body.thumbnail || '',
      duration: body.duration || 0,
      views: 0,
      likes: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    episodes.push(newEpisode);
    writeEpisodes(episodes);
    
    return NextResponse.json({ success: true, data: newEpisode });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error creating episode' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const episodes = readEpisodes();
    const index = episodes.findIndex(e => e.id === body.id);
    
    if (index === -1) {
      return NextResponse.json({ success: false, error: 'Episode not found' }, { status: 404 });
    }
    
    episodes[index] = {
      ...episodes[index],
      ...body,
      updatedAt: new Date().toISOString()
    };
    
    writeEpisodes(episodes);
    return NextResponse.json({ success: true, data: episodes[index] });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error updating episode' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ success: false, error: 'ID is required' }, { status: 400 });
    }
    
    const episodes = readEpisodes();
    const filtered = episodes.filter(e => e.id !== id);
    writeEpisodes(filtered);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error deleting episode' }, { status: 500 });
  }
}
