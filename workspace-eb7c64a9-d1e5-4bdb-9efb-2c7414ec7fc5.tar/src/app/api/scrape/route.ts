import { NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';
import fs from 'fs';
import path from 'path';
import { Anime, Episode } from '@/lib/types';

const dataDir = path.join(process.cwd(), 'public', 'data');

interface ScraperResult {
  animes: Anime[];
  episodes: Episode[];
}

async function readCurrentData() {
  try {
    const animesPath = path.join(dataDir, 'animes.json');
    const episodesPath = path.join(dataDir, 'episodes.json');
    
    const animes = JSON.parse(fs.readFileSync(animesPath, 'utf-8'));
    const episodes = JSON.parse(fs.readFileSync(episodesPath, 'utf-8'));
    
    return { animes, episodes };
  } catch {
    return { animes: [], episodes: [] };
  }
}

function saveData(animes: Anime[], episodes: Episode[]) {
  fs.writeFileSync(path.join(dataDir, 'animes.json'), JSON.stringify(animes, null, 2));
  fs.writeFileSync(path.join(dataDir, 'episodes.json'), JSON.stringify(episodes, null, 2));
}

export async function GET() {
  try {
    const zai = await ZAI.create();
    
    // Use web search to find anime content from animeav1.com
    const searchResult = await zai.functions.invoke("web_search", {
      query: "animeav1.com anime episodes list",
      num: 20
    });
    
    const currentData = await readCurrentData();
    const existingAnimeIds = new Set(currentData.animes.map((a: Anime) => a.id));
    const existingEpisodeIds = new Set(currentData.episodes.map((e: Episode) => e.id));
    
    const newAnimes: Anime[] = [];
    const newEpisodes: Episode[] = [];
    
    // Process search results to extract anime data
    if (Array.isArray(searchResult)) {
      for (const item of searchResult) {
        if (item.name && item.url) {
          // Create anime from search result
          const animeId = `scraped_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          
          if (!existingAnimeIds.has(animeId)) {
            const newAnime: Anime = {
              id: animeId,
              title: item.name.replace(/ - animeav1.*$/i, '').trim(),
              cover: item.favicon || `https://picsum.photos/seed/${animeId}/300/400`,
              description: item.snippet || `Anime extraído desde ${item.host_name}`,
              genre: ['Anime'],
              status: 'ongoing',
              rating: Math.round((Math.random() * 2 + 7) * 10) / 10,
              year: new Date().getFullYear(),
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            };
            
            newAnimes.push(newAnime);
            
            // Create sample episodes for each anime
            const episodeCount = Math.floor(Math.random() * 5) + 3;
            for (let i = 1; i <= episodeCount; i++) {
              const episodeId = `scraped_ep_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
              
              if (!existingEpisodeIds.has(episodeId)) {
                newEpisodes.push({
                  id: episodeId,
                  animeId: animeId,
                  title: `Episodio ${i}`,
                  episodeNumber: i,
                  videoUrl: item.url,
                  thumbnail: `https://picsum.photos/seed/${episodeId}/640/360`,
                  duration: Math.floor(Math.random() * 600) + 1200,
                  views: Math.floor(Math.random() * 100000),
                  likes: Math.floor(Math.random() * 10000),
                  createdAt: new Date().toISOString(),
                  updatedAt: new Date().toISOString()
                });
              }
            }
          }
        }
      }
    }
    
    // Also search for popular anime
    const popularSearch = await zai.functions.invoke("web_search", {
      query: "animeav1.com naruto attack on titan demon slayer",
      num: 15
    });
    
    if (Array.isArray(popularSearch)) {
      for (const item of popularSearch) {
        if (item.name && item.url && !item.url.includes('login')) {
          const animeId = `popular_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
          
          // Extract anime name from title
          let animeName = item.name;
          const patterns = [
            /(.+?)\s+Episodio/i,
            /(.+?)\s+Capítulo/i,
            /(.+?)\s+-\s+animeav/i,
            /(.+?)\s+Sub Español/i
          ];
          
          for (const pattern of patterns) {
            const match = animeName.match(pattern);
            if (match) {
              animeName = match[1].trim();
              break;
            }
          }
          
          if (!existingAnimeIds.has(animeId) && animeName.length > 2) {
            newAnimes.push({
              id: animeId,
              title: animeName,
              cover: `https://picsum.photos/seed/${animeId}/300/400`,
              description: item.snippet || `Anime popular: ${animeName}`,
              genre: ['Acción', 'Aventura'],
              status: 'ongoing',
              rating: Math.round((Math.random() * 2 + 7.5) * 10) / 10,
              year: new Date().getFullYear(),
              createdAt: new Date().toISOString(),
              updatedAt: new Date().toISOString()
            });
            
            // Create episodes
            for (let i = 1; i <= 3; i++) {
              const episodeId = `pop_ep_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
              
              newEpisodes.push({
                id: episodeId,
                animeId: animeId,
                title: `Episodio ${i}`,
                episodeNumber: i,
                videoUrl: item.url,
                thumbnail: `https://picsum.photos/seed/${episodeId}/640/360`,
                duration: Math.floor(Math.random() * 600) + 1200,
                views: Math.floor(Math.random() * 200000),
                likes: Math.floor(Math.random() * 20000),
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
              });
            }
          }
        }
      }
    }
    
    // Combine existing data with new scraped data
    const allAnimes = [...currentData.animes, ...newAnimes];
    const allEpisodes = [...currentData.episodes, ...newEpisodes];
    
    // Save combined data
    saveData(allAnimes, allEpisodes);
    
    return NextResponse.json({
      success: true,
      data: {
        newAnimesCount: newAnimes.length,
        newEpisodesCount: newEpisodes.length,
        totalAnimes: allAnimes.length,
        totalEpisodes: allEpisodes.length,
        animes: newAnimes,
        episodes: newEpisodes
      }
    });
    
  } catch (error: unknown) {
    console.error('Scraping error:', error);
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    
    return NextResponse.json({
      success: false,
      error: `Error during scraping: ${errorMessage}`
    }, { status: 500 });
  }
}
