import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { Comment } from '@/lib/types';

const dataDir = path.join(process.cwd(), 'public', 'data');
const commentsFile = path.join(dataDir, 'comments.json');

function readComments(): Comment[] {
  try {
    const data = fs.readFileSync(commentsFile, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

function writeComments(comments: Comment[]) {
  fs.writeFileSync(commentsFile, JSON.stringify(comments, null, 2));
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const episodeId = searchParams.get('episodeId');
    
    let comments = readComments();
    
    if (episodeId) {
      comments = comments.filter(c => c.episodeId === episodeId);
    }
    
    return NextResponse.json({ success: true, data: comments });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error reading comments' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const comments = readComments();
    
    const newComment: Comment = {
      id: `c${Date.now()}`,
      episodeId: body.episodeId,
      userId: body.userId || 'anonymous',
      userName: body.userName || 'Anonymous',
      userAvatar: body.userAvatar || `https://api.dicebear.com/7.x/avataaars/svg?seed=${Date.now()}`,
      content: body.content,
      likes: 0,
      replies: [],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    comments.push(newComment);
    writeComments(comments);
    
    return NextResponse.json({ success: true, data: newComment });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error creating comment' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ success: false, error: 'ID is required' }, { status: 400 });
    }
    
    const comments = readComments();
    const filtered = comments.filter(c => c.id !== id);
    writeComments(filtered);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error deleting comment' }, { status: 500 });
  }
}
