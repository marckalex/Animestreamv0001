import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { Anime } from '@/lib/types';

const dataDir = path.join(process.cwd(), 'public', 'data');
const animesFile = path.join(dataDir, 'animes.json');

function readAnimes(): Anime[] {
  try {
    const data = fs.readFileSync(animesFile, 'utf-8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

function writeAnimes(animes: Anime[]) {
  fs.writeFileSync(animesFile, JSON.stringify(animes, null, 2));
}

export async function GET() {
  try {
    const animes = readAnimes();
    return NextResponse.json({ success: true, data: animes });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error reading animes' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const animes = readAnimes();
    
    const newAnime: Anime = {
      id: `a${Date.now()}`,
      title: body.title,
      cover: body.cover || '',
      description: body.description || '',
      genre: body.genre || [],
      status: body.status || 'ongoing',
      rating: body.rating || 0,
      year: body.year || new Date().getFullYear(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    animes.push(newAnime);
    writeAnimes(animes);
    
    return NextResponse.json({ success: true, data: newAnime });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error creating anime' }, { status: 500 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const animes = readAnimes();
    const index = animes.findIndex(a => a.id === body.id);
    
    if (index === -1) {
      return NextResponse.json({ success: false, error: 'Anime not found' }, { status: 404 });
    }
    
    animes[index] = {
      ...animes[index],
      ...body,
      updatedAt: new Date().toISOString()
    };
    
    writeAnimes(animes);
    return NextResponse.json({ success: true, data: animes[index] });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error updating anime' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    
    if (!id) {
      return NextResponse.json({ success: false, error: 'ID is required' }, { status: 400 });
    }
    
    const animes = readAnimes();
    const filtered = animes.filter(a => a.id !== id);
    writeAnimes(filtered);
    
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Error deleting anime' }, { status: 500 });
  }
}
