'use client';

import { useState, useEffect, useCallback } from 'react';
import { Anime, Episode, Comment } from '@/lib/types';
import { useIsMobile } from '@/hooks/use-mobile';
import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';
import { VideoFeed } from '@/components/video/VideoFeed';
import { VideoGrid } from '@/components/video/VideoGrid';
import { VideoPlayer } from '@/components/video/VideoPlayer';
import { StudioDashboard } from '@/components/studio/StudioDashboard';
import { cn } from '@/lib/utils';

type AppView = 'home' | 'player' | 'studio';

export default function Home() {
  const isMobile = useIsMobile();
  
  // Data state
  const [animes, setAnimes] = useState<Anime[]>([]);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [likedEpisodes, setLikedEpisodes] = useState<Set<string>>(new Set());
  
  // UI state
  const [appView, setAppView] = useState<AppView>('home');
  const [selectedAnime, setSelectedAnime] = useState<Anime | null>(null);
  const [currentEpisode, setCurrentEpisode] = useState<Episode | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isScraping, setIsScraping] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  
  // Feed pagination
  const [feedPage, setFeedPage] = useState(0);
  const EPISODES_PER_PAGE = 10;

  // Load initial data
  useEffect(() => {
    loadData();
    loadLikedFromStorage();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/data');
      const data = await response.json();
      
      if (data.success) {
        setAnimes(data.data.animes || []);
        setEpisodes(data.data.episodes || []);
        setComments(data.data.comments || []);
        
        // Set first episode for mobile feed
        if (data.data.episodes?.length > 0 && isMobile) {
          setCurrentEpisode(data.data.episodes[0]);
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const loadLikedFromStorage = () => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('likedEpisodes');
      if (stored) {
        setLikedEpisodes(new Set(JSON.parse(stored)));
      }
    }
  };

  const saveLikedToStorage = (liked: Set<string>) => {
    localStorage.setItem('likedEpisodes', JSON.stringify([...liked]));
  };

  // Scraper function
  const handleScrape = async () => {
    setIsScraping(true);
    try {
      const response = await fetch('/api/scrape');
      const data = await response.json();
      
      if (data.success) {
        // Reload data after scraping
        await loadData();
      } else {
        console.error('Scraping failed:', data.error);
      }
    } catch (error) {
      console.error('Scraping error:', error);
    } finally {
      setIsScraping(false);
    }
  };

  // Anime CRUD
  const handleUpdateAnime = async (anime: Anime) => {
    try {
      await fetch('/api/animes', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(anime)
      });
      await loadData();
    } catch (error) {
      console.error('Error updating anime:', error);
    }
  };

  const handleDeleteAnime = async (id: string) => {
    try {
      await fetch(`/api/animes?id=${id}`, { method: 'DELETE' });
      await loadData();
    } catch (error) {
      console.error('Error deleting anime:', error);
    }
  };

  // Episode CRUD
  const handleUpdateEpisode = async (episode: Episode) => {
    try {
      await fetch('/api/episodes', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(episode)
      });
      await loadData();
    } catch (error) {
      console.error('Error updating episode:', error);
    }
  };

  const handleDeleteEpisode = async (id: string) => {
    try {
      await fetch(`/api/episodes?id=${id}`, { method: 'DELETE' });
      await loadData();
    } catch (error) {
      console.error('Error deleting episode:', error);
    }
  };

  // Comment CRUD
  const handleDeleteComment = async (id: string) => {
    try {
      await fetch(`/api/comments?id=${id}`, { method: 'DELETE' });
      await loadData();
    } catch (error) {
      console.error('Error deleting comment:', error);
    }
  };

  // Like functionality
  const handleLike = useCallback(() => {
    if (!currentEpisode) return;
    
    const newLiked = new Set(likedEpisodes);
    if (newLiked.has(currentEpisode.id)) {
      newLiked.delete(currentEpisode.id);
    } else {
      newLiked.add(currentEpisode.id);
    }
    setLikedEpisodes(newLiked);
    saveLikedToStorage(newLiked);
  }, [currentEpisode, likedEpisodes]);

  // Comment functionality
  const handleAddComment = async (content: string) => {
    if (!currentEpisode) return;
    
    try {
      await fetch('/api/comments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          episodeId: currentEpisode.id,
          content,
          userName: 'Usuario Anónimo'
        })
      });
      await loadData();
    } catch (error) {
      console.error('Error adding comment:', error);
    }
  };

  // Episode selection
  const handleSelectEpisode = useCallback((episode: Episode) => {
    setCurrentEpisode(episode);
    setAppView('player');
  }, []);

  // Dark mode toggle
  const handleToggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  // Feed navigation
  const handleFeedEndReached = () => {
    setFeedPage(prev => prev + 1);
  };

  // Filter episodes based on search
  const filteredEpisodes = episodes.filter(ep => {
    if (!searchQuery) return true;
    const anime = animes.find(a => a.id === ep.animeId);
    return (
      ep.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      anime?.title.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  // Get comments for current episode
  const currentEpisodeComments = currentEpisode
    ? comments.filter(c => c.episodeId === currentEpisode.id)
    : [];

  // Get related episodes
  const relatedEpisodes = currentEpisode
    ? episodes.filter(e => e.animeId === currentEpisode.animeId && e.id !== currentEpisode.id)
    : [];

  // Mobile navigation handlers
  const handleMobileNext = useCallback(() => {
    const currentIndex = filteredEpisodes.findIndex(e => e.id === currentEpisode?.id);
    if (currentIndex < filteredEpisodes.length - 1) {
      setCurrentEpisode(filteredEpisodes[currentIndex + 1]);
    }
  }, [currentEpisode, filteredEpisodes]);

  const handleMobilePrev = useCallback(() => {
    const currentIndex = filteredEpisodes.findIndex(e => e.id === currentEpisode?.id);
    if (currentIndex > 0) {
      setCurrentEpisode(filteredEpisodes[currentIndex - 1]);
    }
  }, [currentEpisode, filteredEpisodes]);

  // Loading state
  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center mx-auto mb-4 animate-pulse">
            <span className="text-white font-bold text-2xl">A</span>
          </div>
          <p className="text-muted-foreground">Cargando contenido...</p>
        </div>
      </div>
    );
  }

  // Studio Mode
  if (appView === 'studio') {
    return (
      <StudioDashboard
        animes={animes}
        episodes={episodes}
        comments={comments}
        onScrape={handleScrape}
        onUpdateAnime={handleUpdateAnime}
        onDeleteAnime={handleDeleteAnime}
        onUpdateEpisode={handleUpdateEpisode}
        onDeleteEpisode={handleDeleteEpisode}
        onDeleteComment={handleDeleteComment}
        onClose={() => setAppView('home')}
        isScraping={isScraping}
      />
    );
  }

  // Mobile View (TikTok Style)
  if (isMobile) {
    return (
      <div className="fixed inset-0 bg-black">
        {/* Mobile Header */}
        <header className="fixed top-0 left-0 right-0 h-12 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-between px-4">
          <button
            onClick={() => setAppView('studio')}
            className="text-white text-sm"
          >
            ⚙️ Studio
          </button>
          <h1 className="font-bold text-white">AnimeStream</h1>
          <button
            onClick={() => setSearchQuery('')}
            className="text-white text-sm"
          >
            🔍
          </button>
        </header>

        {/* Search Bar (Mobile) */}
        {searchQuery && (
          <div className="fixed top-12 left-0 right-0 bg-black/80 backdrop-blur-sm z-40 p-3">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Buscar..."
              className="w-full bg-white/10 text-white placeholder-white/50 rounded-lg px-4 py-2 text-sm"
              autoFocus
            />
          </div>
        )}

        {/* Video Feed */}
        {currentEpisode && (
          <VideoFeed
            episodes={filteredEpisodes}
            animes={animes}
            currentEpisode={currentEpisode}
            onSelectEpisode={handleSelectEpisode}
            onEndReached={handleFeedEndReached}
          />
        )}

        {/* Empty State */}
        {episodes.length === 0 && (
          <div className="fixed inset-0 flex items-center justify-center text-white text-center p-8">
            <div>
              <p className="text-xl mb-4">📺 No hay contenido</p>
              <p className="text-sm text-white/70 mb-6">
                Ejecuta el scraper desde el panel de administración
              </p>
              <button
                onClick={() => setAppView('studio')}
                className="bg-white text-black px-6 py-2 rounded-lg text-sm font-medium"
              >
                Ir a Studio
              </button>
            </div>
          </div>
        )}

        {/* Bottom Navigation */}
        <nav className="fixed bottom-0 left-0 right-0 h-16 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-around border-t border-white/10">
          <button className="flex flex-col items-center gap-1 text-white/70">
            <span>🏠</span>
            <span className="text-xs">Inicio</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-white/70">
            <span>🔍</span>
            <span className="text-xs">Buscar</span>
          </button>
          <button className="flex flex-col items-center gap-1 text-white/70">
            <span>❤️</span>
            <span className="text-xs">Favoritos</span>
          </button>
          <button
            onClick={() => setAppView('studio')}
            className="flex flex-col items-center gap-1 text-white/70"
          >
            <span>👤</span>
            <span className="text-xs">Perfil</span>
          </button>
        </nav>
      </div>
    );
  }

  // Desktop View (YouTube Style)
  return (
    <div className={cn("min-h-screen bg-background", isDarkMode && "dark")}>
      {/* Header */}
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
        isSidebarOpen={isSidebarOpen}
        onOpenStudio={() => setAppView('studio')}
        isDarkMode={isDarkMode}
        onToggleDarkMode={handleToggleDarkMode}
      />

      {/* Sidebar */}
      <Sidebar
        animes={animes}
        selectedAnime={selectedAnime}
        onSelectAnime={(anime) => {
          setSelectedAnime(anime);
          setAppView('home');
        }}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        onOpenStudio={() => setAppView('studio')}
        isOpen={isSidebarOpen}
        onToggle={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      {/* Main Content */}
      <main
        className={cn(
          "pt-14 min-h-screen transition-all duration-300",
          isSidebarOpen ? "ml-64" : "ml-0"
        )}
      >
        {appView === 'player' && currentEpisode ? (
          // Player View
          <div className="p-6">
            <button
              onClick={() => {
                setAppView('home');
                setCurrentEpisode(null);
              }}
              className="mb-4 text-muted-foreground hover:text-foreground transition-colors"
            >
              ← Volver al inicio
            </button>
            <VideoPlayer
              episode={currentEpisode}
              anime={animes.find(a => a.id === currentEpisode.animeId)}
              comments={currentEpisodeComments}
              relatedEpisodes={relatedEpisodes}
              isLiked={likedEpisodes.has(currentEpisode.id)}
              onLike={handleLike}
              onComment={handleAddComment}
              onSelectEpisode={handleSelectEpisode}
              isMobile={false}
            />
          </div>
        ) : (
          // Grid View
          <VideoGrid
            episodes={filteredEpisodes}
            animes={animes}
            selectedAnime={selectedAnime}
            onSelectEpisode={handleSelectEpisode}
            hasMore={false}
            onLoadMore={() => {}}
          />
        )}
      </main>
    </div>
  );
}
